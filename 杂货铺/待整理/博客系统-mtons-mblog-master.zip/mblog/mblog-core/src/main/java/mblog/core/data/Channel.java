/*
+--------------------------------------------------------------------------
|   Mblog [#RELEASE_VERSION#]
|   ========================================
|   Copyright (c) 2014, 2015 mtons. All Rights Reserved
|   http://www.mtons.com
|
+---------------------------------------------------------------------------
*/
package mblog.core.data;


import mblog.core.persist.entity.ChannelPO;

import java.io.Serializable;

/**
 * @author langhsu
 *
 */
public class Channel extends ChannelPO implements Serializable {
	private static final long serialVersionUID = 4264359286718556524L;

}
