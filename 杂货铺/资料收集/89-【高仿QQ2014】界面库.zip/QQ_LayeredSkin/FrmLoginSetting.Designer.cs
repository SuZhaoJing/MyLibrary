﻿namespace QQ_LayeredSkin
{
    partial class FrmLoginSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLoginSetting));
            this.BtnCancel = new LayeredSkin.Controls.LayeredButton();
            this.BtnMini = new LayeredSkin.Controls.LayeredButton();
            this.BtnClose = new LayeredSkin.Controls.LayeredButton();
            this.SuspendLayout();
            // 
            // BtnCancel
            // 
            this.BtnCancel.AdaptImage = true;
            this.BtnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnCancel.BaseColor = System.Drawing.Color.Wheat;
            this.BtnCancel.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnCancel.Borders.BottomWidth = 1;
            this.BtnCancel.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnCancel.Borders.LeftWidth = 1;
            this.BtnCancel.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnCancel.Borders.RightWidth = 1;
            this.BtnCancel.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnCancel.Borders.TopWidth = 1;
            this.BtnCancel.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnCancel.Canvas")));
            this.BtnCancel.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnCancel.HaloColor = System.Drawing.Color.White;
            this.BtnCancel.HaloSize = 5;
            this.BtnCancel.HoverImage = global::QQ_LayeredSkin.Properties.Resources.button_login_hover;
            this.BtnCancel.IsPureColor = false;
            this.BtnCancel.Location = new System.Drawing.Point(131, 305);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.NormalImage = global::QQ_LayeredSkin.Properties.Resources.button_login_normal;
            this.BtnCancel.PressedImage = global::QQ_LayeredSkin.Properties.Resources.button_login_down;
            this.BtnCancel.Radius = 10;
            this.BtnCancel.ShowBorder = true;
            this.BtnCancel.Size = new System.Drawing.Size(194, 30);
            this.BtnCancel.TabIndex = 27;
            this.BtnCancel.Text = "返    回";
            this.BtnCancel.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnCancel.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.BtnCancel.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancelClick);
            // 
            // BtnMini
            // 
            this.BtnMini.AdaptImage = true;
            this.BtnMini.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnMini.BaseColor = System.Drawing.Color.Wheat;
            this.BtnMini.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.BottomWidth = 1;
            this.BtnMini.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.LeftWidth = 1;
            this.BtnMini.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.RightWidth = 1;
            this.BtnMini.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.TopWidth = 1;
            this.BtnMini.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnMini.Canvas")));
            this.BtnMini.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnMini.HaloColor = System.Drawing.Color.White;
            this.BtnMini.HaloSize = 5;
            this.BtnMini.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.HoverImage")));
            this.BtnMini.IsPureColor = false;
            this.BtnMini.Location = new System.Drawing.Point(376, 5);
            this.BtnMini.Name = "BtnMini";
            this.BtnMini.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.NormalImage")));
            this.BtnMini.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.PressedImage")));
            this.BtnMini.Radius = 10;
            this.BtnMini.ShowBorder = true;
            this.BtnMini.Size = new System.Drawing.Size(30, 27);
            this.BtnMini.TabIndex = 26;
            this.BtnMini.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnMini.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnMini.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnMini.Click += new System.EventHandler(this.BtnMiniClick);
            // 
            // BtnClose
            // 
            this.BtnClose.AdaptImage = true;
            this.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnClose.BaseColor = System.Drawing.Color.Wheat;
            this.BtnClose.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.BottomWidth = 1;
            this.BtnClose.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.LeftWidth = 1;
            this.BtnClose.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.RightWidth = 1;
            this.BtnClose.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.TopWidth = 1;
            this.BtnClose.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnClose.Canvas")));
            this.BtnClose.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnClose.HaloColor = System.Drawing.Color.White;
            this.BtnClose.HaloSize = 5;
            this.BtnClose.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.HoverImage")));
            this.BtnClose.IsPureColor = false;
            this.BtnClose.Location = new System.Drawing.Point(406, 5);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.NormalImage")));
            this.BtnClose.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.PressedImage")));
            this.BtnClose.Radius = 10;
            this.BtnClose.ShowBorder = true;
            this.BtnClose.Size = new System.Drawing.Size(30, 27);
            this.BtnClose.TabIndex = 25;
            this.BtnClose.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnClose.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnClose.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnClose.Click += new System.EventHandler(this.BtnCloseClick);
            // 
            // FrmLoginSetting
            // 
            this.AnimationType = LayeredSkin.Forms.AnimationTypes.ThreeDTurn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(441, 342);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnMini);
            this.Controls.Add(this.BtnClose);
            this.Name = "FrmLoginSetting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.ResumeLayout(false);

        }

        #endregion

        private LayeredSkin.Controls.LayeredButton BtnCancel;
        private LayeredSkin.Controls.LayeredButton BtnMini;
        private LayeredSkin.Controls.LayeredButton BtnClose;
    }
}