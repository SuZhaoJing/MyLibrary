﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace QQ_LayeredSkin
{
    public partial class FrmLoginSetting : LayeredBaseForm
    {
        private FrmLogin form1;
        public FrmLoginSetting(FrmLogin f)
        {
            InitializeComponent();
            this.form1 = f;
        }
        void Animation_AnimationEnd(object sender, LayeredSkin.Animations.AnimationEventArgs e)
        {
            //this.Hide();
            form1.Location = this.Location;
            form1.Animation.Asc = true;
            form1.Animation.AnimationStarted += Animation_AnimationStarted;
            form1.Animation.Start();
            form1.isShow = true;
            this.Close();
        }

        void Animation_AnimationStarted(object sender, LayeredSkin.Animations.AnimationEventArgs e)
        {
            form1.Show();
            //this.Dispose();
        }

        private void BtnCancelClick(object sender, EventArgs e)
        {
            this.Animation.AnimationEnd += Animation_AnimationEnd;
            this.Close();

        }

        private void BtnCloseClick(object sender, EventArgs e)
        {
            this.Animation.Effect = new LayeredSkin.Animations.GradualCurtainEffect();
            this.Animation.Asc = true;
            //等动画结束后关闭程序
            Thread t = new Thread(new ThreadStart(CloseSystem));
            t.Start();
            Close();
        }

        public void CloseSystem()
        {
            Thread.Sleep(1000);
            System.Environment.Exit(0);
        }

        private void BtnMiniClick(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
