﻿namespace QQ_LayeredSkin
{
    partial class FrmChat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmChat));
            this.chatpanel = new LayeredSkin.Controls.LayeredPanel();
            this.TxtChatRecordMsg = new LayeredSkin.Controls.LayeredTextBox();
            this.ChatTools = new LayeredSkin.Controls.LayeredBaseControl();
            this.QQShowControl = new LayeredSkin.Controls.LayeredBaseControl();
            this.layeredButton2 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton1 = new LayeredSkin.Controls.LayeredButton();
            this.TxtSendMsg = new LayeredSkin.Controls.LayeredTextBox();
            this.ChatTopToolControl = new LayeredSkin.Controls.LayeredBaseControl();
            this.layeredDragBar4 = new LayeredSkin.Controls.LayeredDragBar();
            this.BtnMini = new LayeredSkin.Controls.LayeredButton();
            this.BtnClose = new LayeredSkin.Controls.LayeredButton();
            this.HeadInfomationControl = new LayeredSkin.Controls.LayeredBaseControl();
            this.layeredDragBar3 = new LayeredSkin.Controls.LayeredDragBar();
            this.layeredDragBar1 = new LayeredSkin.Controls.LayeredDragBar();
            this.layeredDragBar2 = new LayeredSkin.Controls.LayeredDragBar();
            this.chatpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // chatpanel
            // 
            this.chatpanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.chatpanel.Borders.BottomColor = System.Drawing.Color.Empty;
            this.chatpanel.Borders.BottomWidth = 1;
            this.chatpanel.Borders.LeftColor = System.Drawing.Color.Empty;
            this.chatpanel.Borders.LeftWidth = 1;
            this.chatpanel.Borders.RightColor = System.Drawing.Color.Empty;
            this.chatpanel.Borders.RightWidth = 1;
            this.chatpanel.Borders.TopColor = System.Drawing.Color.Empty;
            this.chatpanel.Borders.TopWidth = 1;
            this.chatpanel.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("chatpanel.Canvas")));
            this.chatpanel.Controls.Add(this.TxtChatRecordMsg);
            this.chatpanel.Controls.Add(this.ChatTools);
            this.chatpanel.Controls.Add(this.QQShowControl);
            this.chatpanel.Controls.Add(this.layeredButton2);
            this.chatpanel.Controls.Add(this.layeredButton1);
            this.chatpanel.Controls.Add(this.TxtSendMsg);
            this.chatpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chatpanel.Location = new System.Drawing.Point(6, 99);
            this.chatpanel.Name = "chatpanel";
            this.chatpanel.Size = new System.Drawing.Size(595, 419);
            this.chatpanel.TabIndex = 49;
            // 
            // TxtChatRecordMsg
            // 
            this.TxtChatRecordMsg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TxtChatRecordMsg.Borders.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TxtChatRecordMsg.Borders.BottomWidth = 1;
            this.TxtChatRecordMsg.Borders.LeftColor = System.Drawing.Color.Empty;
            this.TxtChatRecordMsg.Borders.LeftWidth = 1;
            this.TxtChatRecordMsg.Borders.RightColor = System.Drawing.Color.Empty;
            this.TxtChatRecordMsg.Borders.RightWidth = 1;
            this.TxtChatRecordMsg.Borders.TopColor = System.Drawing.Color.Empty;
            this.TxtChatRecordMsg.Borders.TopWidth = 1;
            this.TxtChatRecordMsg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtChatRecordMsg.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("TxtChatRecordMsg.Canvas")));
            this.TxtChatRecordMsg.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxtChatRecordMsg.Location = new System.Drawing.Point(3, 3);
            this.TxtChatRecordMsg.Multiline = true;
            this.TxtChatRecordMsg.Name = "TxtChatRecordMsg";
            this.TxtChatRecordMsg.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.TxtChatRecordMsg.Size = new System.Drawing.Size(421, 228);
            this.TxtChatRecordMsg.TabIndex = 43;
            this.TxtChatRecordMsg.TransparencyKey = System.Drawing.Color.Empty;
            this.TxtChatRecordMsg.WaterFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxtChatRecordMsg.WaterText = "";
            this.TxtChatRecordMsg.WaterTextOffset = new System.Drawing.Point(0, 0);
            // 
            // ChatTools
            // 
            this.ChatTools.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ChatTools.Borders.BottomColor = System.Drawing.Color.Empty;
            this.ChatTools.Borders.BottomWidth = 1;
            this.ChatTools.Borders.LeftColor = System.Drawing.Color.Empty;
            this.ChatTools.Borders.LeftWidth = 1;
            this.ChatTools.Borders.RightColor = System.Drawing.Color.Empty;
            this.ChatTools.Borders.RightWidth = 1;
            this.ChatTools.Borders.TopColor = System.Drawing.Color.Empty;
            this.ChatTools.Borders.TopWidth = 1;
            this.ChatTools.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("ChatTools.Canvas")));
            this.ChatTools.Location = new System.Drawing.Point(3, 233);
            this.ChatTools.Name = "ChatTools";
            this.ChatTools.Size = new System.Drawing.Size(421, 30);
            this.ChatTools.TabIndex = 46;
            this.ChatTools.Text = "layeredBaseControl1";
            // 
            // QQShowControl
            // 
            this.QQShowControl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.QQShowControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.QQShowControl.Borders.BottomColor = System.Drawing.Color.Empty;
            this.QQShowControl.Borders.BottomWidth = 1;
            this.QQShowControl.Borders.LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.QQShowControl.Borders.LeftWidth = 1;
            this.QQShowControl.Borders.RightColor = System.Drawing.Color.Empty;
            this.QQShowControl.Borders.RightWidth = 1;
            this.QQShowControl.Borders.TopColor = System.Drawing.Color.Empty;
            this.QQShowControl.Borders.TopWidth = 1;
            this.QQShowControl.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("QQShowControl.Canvas")));
            this.QQShowControl.Location = new System.Drawing.Point(425, 3);
            this.QQShowControl.Name = "QQShowControl";
            this.QQShowControl.Size = new System.Drawing.Size(169, 416);
            this.QQShowControl.TabIndex = 45;
            this.QQShowControl.Text = "QQ秀";
            this.QQShowControl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MoveFormMouseDown);
            // 
            // layeredButton2
            // 
            this.layeredButton2.AdaptImage = true;
            this.layeredButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.BottomWidth = 1;
            this.layeredButton2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.LeftWidth = 1;
            this.layeredButton2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.RightWidth = 1;
            this.layeredButton2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.TopWidth = 1;
            this.layeredButton2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton2.Canvas")));
            this.layeredButton2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredButton2.ForeColor = System.Drawing.Color.White;
            this.layeredButton2.HaloColor = System.Drawing.Color.White;
            this.layeredButton2.HaloSize = 5;
            this.layeredButton2.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.HoverImage")));
            this.layeredButton2.IsPureColor = false;
            this.layeredButton2.Location = new System.Drawing.Point(221, 381);
            this.layeredButton2.Name = "layeredButton2";
            this.layeredButton2.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.NormalImage")));
            this.layeredButton2.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.PressedImage")));
            this.layeredButton2.Radius = 10;
            this.layeredButton2.ShowBorder = true;
            this.layeredButton2.Size = new System.Drawing.Size(96, 30);
            this.layeredButton2.TabIndex = 41;
            this.layeredButton2.Text = "关闭";
            this.layeredButton2.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton2.TextShowMode = LayeredSkin.TextShowModes.Ordinary;
            this.layeredButton2.Click += new System.EventHandler(this.layeredButton2_Click);
            // 
            // layeredButton1
            // 
            this.layeredButton1.AdaptImage = true;
            this.layeredButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton1.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.BottomWidth = 1;
            this.layeredButton1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.LeftWidth = 1;
            this.layeredButton1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.RightWidth = 1;
            this.layeredButton1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.TopWidth = 1;
            this.layeredButton1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton1.Canvas")));
            this.layeredButton1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredButton1.ForeColor = System.Drawing.Color.White;
            this.layeredButton1.HaloColor = System.Drawing.Color.White;
            this.layeredButton1.HaloSize = 5;
            this.layeredButton1.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.HoverImage")));
            this.layeredButton1.IsPureColor = false;
            this.layeredButton1.Location = new System.Drawing.Point(323, 381);
            this.layeredButton1.Name = "layeredButton1";
            this.layeredButton1.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.NormalImage")));
            this.layeredButton1.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.PressedImage")));
            this.layeredButton1.Radius = 10;
            this.layeredButton1.ShowBorder = true;
            this.layeredButton1.Size = new System.Drawing.Size(96, 30);
            this.layeredButton1.TabIndex = 41;
            this.layeredButton1.Text = "发送";
            this.layeredButton1.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton1.TextShowMode = LayeredSkin.TextShowModes.Ordinary;
            this.layeredButton1.Click += new System.EventHandler(this.layeredButton1_Click);
            // 
            // TxtSendMsg
            // 
            this.TxtSendMsg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TxtSendMsg.Borders.BottomColor = System.Drawing.Color.Empty;
            this.TxtSendMsg.Borders.BottomWidth = 1;
            this.TxtSendMsg.Borders.LeftColor = System.Drawing.Color.Empty;
            this.TxtSendMsg.Borders.LeftWidth = 1;
            this.TxtSendMsg.Borders.RightColor = System.Drawing.Color.Empty;
            this.TxtSendMsg.Borders.RightWidth = 1;
            this.TxtSendMsg.Borders.TopColor = System.Drawing.Color.Empty;
            this.TxtSendMsg.Borders.TopWidth = 1;
            this.TxtSendMsg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtSendMsg.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("TxtSendMsg.Canvas")));
            this.TxtSendMsg.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxtSendMsg.Location = new System.Drawing.Point(3, 265);
            this.TxtSendMsg.Multiline = true;
            this.TxtSendMsg.Name = "TxtSendMsg";
            this.TxtSendMsg.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.TxtSendMsg.Size = new System.Drawing.Size(421, 108);
            this.TxtSendMsg.TabIndex = 42;
            this.TxtSendMsg.TransparencyKey = System.Drawing.Color.Empty;
            this.TxtSendMsg.WaterFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxtSendMsg.WaterText = "";
            this.TxtSendMsg.WaterTextOffset = new System.Drawing.Point(0, 0);
            // 
            // ChatTopToolControl
            // 
            this.ChatTopToolControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ChatTopToolControl.Borders.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ChatTopToolControl.Borders.BottomWidth = 1;
            this.ChatTopToolControl.Borders.LeftColor = System.Drawing.Color.Empty;
            this.ChatTopToolControl.Borders.LeftWidth = 1;
            this.ChatTopToolControl.Borders.RightColor = System.Drawing.Color.Empty;
            this.ChatTopToolControl.Borders.RightWidth = 1;
            this.ChatTopToolControl.Borders.TopColor = System.Drawing.Color.Empty;
            this.ChatTopToolControl.Borders.TopWidth = 1;
            this.ChatTopToolControl.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("ChatTopToolControl.Canvas")));
            this.ChatTopToolControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.ChatTopToolControl.Location = new System.Drawing.Point(6, 56);
            this.ChatTopToolControl.Name = "ChatTopToolControl";
            this.ChatTopToolControl.Size = new System.Drawing.Size(595, 43);
            this.ChatTopToolControl.TabIndex = 46;
            // 
            // layeredDragBar4
            // 
            this.layeredDragBar4.AdaptImage = true;
            this.layeredDragBar4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredDragBar4.BaseColor = System.Drawing.Color.Wheat;
            this.layeredDragBar4.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredDragBar4.Borders.BottomWidth = 1;
            this.layeredDragBar4.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredDragBar4.Borders.LeftWidth = 1;
            this.layeredDragBar4.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredDragBar4.Borders.RightWidth = 1;
            this.layeredDragBar4.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredDragBar4.Borders.TopWidth = 1;
            this.layeredDragBar4.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredDragBar4.Canvas")));
            this.layeredDragBar4.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredDragBar4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.layeredDragBar4.DragBarPosition = LayeredSkin.Controls.DragBarPositions.Bottom;
            this.layeredDragBar4.DrawDragBar = true;
            this.layeredDragBar4.ForeColor = System.Drawing.Color.White;
            this.layeredDragBar4.HaloColor = System.Drawing.Color.White;
            this.layeredDragBar4.HaloSize = 5;
            this.layeredDragBar4.HoverImage = null;
            this.layeredDragBar4.IsPureColor = false;
            this.layeredDragBar4.Location = new System.Drawing.Point(6, 518);
            this.layeredDragBar4.Name = "layeredDragBar4";
            this.layeredDragBar4.NormalImage = null;
            this.layeredDragBar4.PressedImage = null;
            this.layeredDragBar4.Radius = 10;
            this.layeredDragBar4.ShowBorder = true;
            this.layeredDragBar4.Size = new System.Drawing.Size(595, 1);
            this.layeredDragBar4.TabIndex = 38;
            this.layeredDragBar4.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredDragBar4.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredDragBar4.TextShowMode = LayeredSkin.TextShowModes.None;
            // 
            // BtnMini
            // 
            this.BtnMini.AdaptImage = true;
            this.BtnMini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnMini.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnMini.BaseColor = System.Drawing.Color.Wheat;
            this.BtnMini.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.BottomWidth = 1;
            this.BtnMini.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.LeftWidth = 1;
            this.BtnMini.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.RightWidth = 1;
            this.BtnMini.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.TopWidth = 1;
            this.BtnMini.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnMini.Canvas")));
            this.BtnMini.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnMini.HaloColor = System.Drawing.Color.White;
            this.BtnMini.HaloSize = 5;
            this.BtnMini.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.HoverImage")));
            this.BtnMini.IsPureColor = false;
            this.BtnMini.Location = new System.Drawing.Point(541, 6);
            this.BtnMini.Name = "BtnMini";
            this.BtnMini.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.NormalImage")));
            this.BtnMini.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.PressedImage")));
            this.BtnMini.Radius = 10;
            this.BtnMini.ShowBorder = true;
            this.BtnMini.Size = new System.Drawing.Size(30, 27);
            this.BtnMini.TabIndex = 48;
            this.BtnMini.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnMini.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnMini.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnMini.Click += new System.EventHandler(this.BtnMini_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.AdaptImage = true;
            this.BtnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnClose.BaseColor = System.Drawing.Color.Wheat;
            this.BtnClose.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.BottomWidth = 1;
            this.BtnClose.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.LeftWidth = 1;
            this.BtnClose.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.RightWidth = 1;
            this.BtnClose.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.TopWidth = 1;
            this.BtnClose.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnClose.Canvas")));
            this.BtnClose.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnClose.HaloColor = System.Drawing.Color.White;
            this.BtnClose.HaloSize = 5;
            this.BtnClose.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.HoverImage")));
            this.BtnClose.IsPureColor = false;
            this.BtnClose.Location = new System.Drawing.Point(571, 6);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.NormalImage")));
            this.BtnClose.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.PressedImage")));
            this.BtnClose.Radius = 10;
            this.BtnClose.ShowBorder = true;
            this.BtnClose.Size = new System.Drawing.Size(30, 27);
            this.BtnClose.TabIndex = 47;
            this.BtnClose.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnClose.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnClose.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnClose.Click += new System.EventHandler(this.layeredButton2_Click);
            // 
            // HeadInfomationControl
            // 
            this.HeadInfomationControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.HeadInfomationControl.Borders.BottomColor = System.Drawing.Color.Empty;
            this.HeadInfomationControl.Borders.BottomWidth = 1;
            this.HeadInfomationControl.Borders.LeftColor = System.Drawing.Color.Empty;
            this.HeadInfomationControl.Borders.LeftWidth = 1;
            this.HeadInfomationControl.Borders.RightColor = System.Drawing.Color.Empty;
            this.HeadInfomationControl.Borders.RightWidth = 1;
            this.HeadInfomationControl.Borders.TopColor = System.Drawing.Color.Empty;
            this.HeadInfomationControl.Borders.TopWidth = 1;
            this.HeadInfomationControl.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("HeadInfomationControl.Canvas")));
            this.HeadInfomationControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeadInfomationControl.Location = new System.Drawing.Point(6, 6);
            this.HeadInfomationControl.Name = "HeadInfomationControl";
            this.HeadInfomationControl.Size = new System.Drawing.Size(595, 50);
            this.HeadInfomationControl.TabIndex = 44;
            this.HeadInfomationControl.Text = "头部信息";
            this.HeadInfomationControl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MoveFormMouseDown);
            // 
            // layeredDragBar3
            // 
            this.layeredDragBar3.AdaptImage = true;
            this.layeredDragBar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredDragBar3.BaseColor = System.Drawing.Color.Wheat;
            this.layeredDragBar3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredDragBar3.Borders.BottomWidth = 1;
            this.layeredDragBar3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredDragBar3.Borders.LeftWidth = 1;
            this.layeredDragBar3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredDragBar3.Borders.RightWidth = 1;
            this.layeredDragBar3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredDragBar3.Borders.TopWidth = 1;
            this.layeredDragBar3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredDragBar3.Canvas")));
            this.layeredDragBar3.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredDragBar3.Dock = System.Windows.Forms.DockStyle.Top;
            this.layeredDragBar3.DragBarPosition = LayeredSkin.Controls.DragBarPositions.Top;
            this.layeredDragBar3.DrawDragBar = true;
            this.layeredDragBar3.ForeColor = System.Drawing.Color.White;
            this.layeredDragBar3.HaloColor = System.Drawing.Color.White;
            this.layeredDragBar3.HaloSize = 5;
            this.layeredDragBar3.HoverImage = null;
            this.layeredDragBar3.IsPureColor = false;
            this.layeredDragBar3.Location = new System.Drawing.Point(6, 5);
            this.layeredDragBar3.Name = "layeredDragBar3";
            this.layeredDragBar3.NormalImage = null;
            this.layeredDragBar3.PressedImage = null;
            this.layeredDragBar3.Radius = 10;
            this.layeredDragBar3.ShowBorder = true;
            this.layeredDragBar3.Size = new System.Drawing.Size(595, 1);
            this.layeredDragBar3.TabIndex = 37;
            this.layeredDragBar3.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredDragBar3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredDragBar3.TextShowMode = LayeredSkin.TextShowModes.None;
            // 
            // layeredDragBar1
            // 
            this.layeredDragBar1.AdaptImage = true;
            this.layeredDragBar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredDragBar1.BaseColor = System.Drawing.Color.Wheat;
            this.layeredDragBar1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredDragBar1.Borders.BottomWidth = 1;
            this.layeredDragBar1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredDragBar1.Borders.LeftWidth = 1;
            this.layeredDragBar1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredDragBar1.Borders.RightWidth = 1;
            this.layeredDragBar1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredDragBar1.Borders.TopWidth = 1;
            this.layeredDragBar1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredDragBar1.Canvas")));
            this.layeredDragBar1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredDragBar1.Dock = System.Windows.Forms.DockStyle.Right;
            this.layeredDragBar1.DragBarPosition = LayeredSkin.Controls.DragBarPositions.Right;
            this.layeredDragBar1.DrawDragBar = true;
            this.layeredDragBar1.ForeColor = System.Drawing.Color.White;
            this.layeredDragBar1.HaloColor = System.Drawing.Color.White;
            this.layeredDragBar1.HaloSize = 5;
            this.layeredDragBar1.HoverImage = null;
            this.layeredDragBar1.IsPureColor = false;
            this.layeredDragBar1.Location = new System.Drawing.Point(601, 5);
            this.layeredDragBar1.Name = "layeredDragBar1";
            this.layeredDragBar1.NormalImage = null;
            this.layeredDragBar1.PressedImage = null;
            this.layeredDragBar1.Radius = 10;
            this.layeredDragBar1.ShowBorder = true;
            this.layeredDragBar1.Size = new System.Drawing.Size(1, 514);
            this.layeredDragBar1.TabIndex = 35;
            this.layeredDragBar1.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredDragBar1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredDragBar1.TextShowMode = LayeredSkin.TextShowModes.None;
            // 
            // layeredDragBar2
            // 
            this.layeredDragBar2.AdaptImage = true;
            this.layeredDragBar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredDragBar2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredDragBar2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredDragBar2.Borders.BottomWidth = 1;
            this.layeredDragBar2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredDragBar2.Borders.LeftWidth = 1;
            this.layeredDragBar2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredDragBar2.Borders.RightWidth = 1;
            this.layeredDragBar2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredDragBar2.Borders.TopWidth = 1;
            this.layeredDragBar2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredDragBar2.Canvas")));
            this.layeredDragBar2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredDragBar2.Dock = System.Windows.Forms.DockStyle.Left;
            this.layeredDragBar2.DragBarPosition = LayeredSkin.Controls.DragBarPositions.Left;
            this.layeredDragBar2.DrawDragBar = true;
            this.layeredDragBar2.ForeColor = System.Drawing.Color.White;
            this.layeredDragBar2.HaloColor = System.Drawing.Color.White;
            this.layeredDragBar2.HaloSize = 5;
            this.layeredDragBar2.HoverImage = null;
            this.layeredDragBar2.IsPureColor = false;
            this.layeredDragBar2.Location = new System.Drawing.Point(5, 5);
            this.layeredDragBar2.Name = "layeredDragBar2";
            this.layeredDragBar2.NormalImage = null;
            this.layeredDragBar2.PressedImage = null;
            this.layeredDragBar2.Radius = 10;
            this.layeredDragBar2.ShowBorder = true;
            this.layeredDragBar2.Size = new System.Drawing.Size(1, 514);
            this.layeredDragBar2.TabIndex = 36;
            this.layeredDragBar2.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredDragBar2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredDragBar2.TextShowMode = LayeredSkin.TextShowModes.None;
            // 
            // FrmChat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(607, 524);
            this.Controls.Add(this.chatpanel);
            this.Controls.Add(this.ChatTopToolControl);
            this.Controls.Add(this.layeredDragBar4);
            this.Controls.Add(this.BtnMini);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.HeadInfomationControl);
            this.Controls.Add(this.layeredDragBar3);
            this.Controls.Add(this.layeredDragBar1);
            this.Controls.Add(this.layeredDragBar2);
            this.Name = "FrmChat";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FrmChat_Load);
            this.chatpanel.ResumeLayout(false);
            this.chatpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private LayeredSkin.Controls.LayeredBaseControl QQShowControl;
        private LayeredSkin.Controls.LayeredBaseControl HeadInfomationControl;
        private LayeredSkin.Controls.LayeredTextBox TxtSendMsg;
        private LayeredSkin.Controls.LayeredTextBox TxtChatRecordMsg;
        private LayeredSkin.Controls.LayeredButton layeredButton1;
        private LayeredSkin.Controls.LayeredDragBar layeredDragBar3;
        private LayeredSkin.Controls.LayeredDragBar layeredDragBar4;
        private LayeredSkin.Controls.LayeredDragBar layeredDragBar1;
        private LayeredSkin.Controls.LayeredDragBar layeredDragBar2;
        private LayeredSkin.Controls.LayeredBaseControl ChatTools;
        private LayeredSkin.Controls.LayeredButton BtnMini;
        private LayeredSkin.Controls.LayeredButton BtnClose;
        private LayeredSkin.Controls.LayeredPanel chatpanel;
        private LayeredSkin.Controls.LayeredButton layeredButton2;
        private LayeredSkin.Controls.LayeredBaseControl ChatTopToolControl;
    }
}