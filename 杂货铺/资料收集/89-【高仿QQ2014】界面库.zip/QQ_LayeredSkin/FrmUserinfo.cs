﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using LayeredSkin.DirectUI;
using QQ_LayeredSkin.Properties;

namespace QQ_LayeredSkin
{
    public partial class FrmUserinfo : LayeredBaseForm
    {
        private Point point;
        public bool IsClose = false;
        public FrmUserinfo(Point p)
        {
            InitializeComponent();
            this.point = p;

        }
        #region 窗体位置

        private Point loactionPoint;

        public Point LoactionPoint
        {
            get
            {
                return loactionPoint;
            }
            set
            {
                loactionPoint = value;
            }
        }

        public void SetLoaction(Point _Point)
        {
            this.Location = _Point;
        }

        #endregion

        #region 渐变效果

        public bool isOpend = false;
        /// <summary>
        /// 隐藏
        /// </summary>
        public new void Hide()
        {
            if (timShow.Enabled == false)
            {
                timShow.Enabled = true;
            }
        }

        /// <summary>
        /// 显示
        /// </summary>
        public new void Show()
        {
            if (isOpend == false)
            {
                base.Show();
                ShowMove();
            }
            isOpend = true;
        }

        //渐变效果
        System.Timers.Timer tmShow;

        private void ShowMove()
        {
            this.Location = new Point(loactionPoint.X, loactionPoint.Y - 40);
            tmShow.Start();
        }

        void tmShow_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            //需要显示
            if (isOpend == true)
            {
                this.BeginInvoke((MethodInvoker)delegate()
                {
                    this.Location = new Point(this.Location.X, this.Location.Y + 5);
                    if (this.Location.Y >= loactionPoint.Y)
                    {
                        tmShow.Stop();
                    }
                });
            }
            else//需要隐藏
            {
                this.BeginInvoke((MethodInvoker)delegate()
                {
                    Close();
                    tmShow.Stop();
                    //this.Location = new Point(this.Location.X, this.Location.Y - 5);
                    //if (this.Location.Y <= loactionPoint.Y - 40)
                    //{
                    //    base.Hide();
                    //    tmShow.Stop();
                    //}
                });
            }

        }
        #endregion
        private void timShow_Tick(object sender, EventArgs e)
        {
            //鼠标不在窗体内时
            if (!this.Bounds.Contains(Cursor.Position) )
            {
                this.BeginInvoke((MethodInvoker)delegate()
                {
                    isOpend = false;
                    tmShow.Start();
                    loactionPoint = this.Location;
                    timShow.Enabled = false;
                });
            }
            else if (this.Bounds.Contains(Cursor.Position))
            {
                this.Show();
            }
        }

        public void BaseHide()
        {
            base.Hide();
        }
        public void BaseShow()
        {
            base.Show();
        }
        public void TimShow(bool flag)
        {
            timShow.Enabled = flag;
        }

        private void FrmWeather_Load(object sender, EventArgs e)
        {
            //滚动效果
            tmShow = new System.Timers.Timer();
            tmShow.Elapsed += new System.Timers.ElapsedEventHandler(tmShow_Elapsed);
            tmShow.Interval = 5;


        }

        public void RefleshChatData(string uin, string nicname, string displaymsg)
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(N =>
            {
                ToolsControl.BackColor = Color.FromArgb(100, Color.White);
                QQShow.BackColor = Color.White;
                DuiBaseControl name = DuiBaseControlClass.AddDuiLabel(nicname, DuiBaseControlClass.Titlefont, new Size(279, 30), new Point(115, 0));
                DuiBaseControl msg = DuiBaseControlClass.AddDuiLabel(displaymsg, DuiBaseControlClass.Msgfont, new Size(130, 15), new Point(115, 30));
                InfomationControl.DUIControls.Clear();
                DuiBaseControl whitebg = DuiBaseControlClass.AddDuiLabel("", DuiBaseControlClass.Msgfont,
                    new Size(279, InfomationControl.Height - 80), new Point(0, 80));
                InfomationControl.DUIControls.Add(name);

                InfomationControl.DUIControls.Add(msg);
                whitebg.BackColor = Color.FromArgb(200, Color.White);
                InfomationControl.DUIControls.Add(whitebg);
                ToolsControl.Visible = true;
                this.Height = 260;
                #region 初始化第一行16*16工具栏

                Bitmap[] btmBitmaps1 = new Bitmap[6]
                {
                    Resources.weiyun, Resources.webqq_16, Resources.chongwu, Resources.music, Resources.qqgame_16,
                    Resources.chong
                };
                for (int i = 0; i < 1; i++)
                {
                    AddBottontoolItems16(btmBitmaps1[i + 1], new Size(20, 20), i, 0);

                }
                for (int i = 0; i < btmBitmaps1.Length - 1; i++)
                {
                    AddBottontoolItems16(btmBitmaps1[i + 1], new Size(20, 20), i, 0);

                }
                #endregion
            }));

        }
        /// <summary>
        /// 添加我的信息
        /// </summary>
        public void MyInfo(string nicname, string displaymsg)
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(N =>
            {
                ToolsControl.BackColor = Color.FromArgb(100, Color.White);
                QQShow.BackColor = Color.White;
                DuiBaseControl name = DuiBaseControlClass.AddDuiLabel(nicname, DuiBaseControlClass.Titlefont, new Size(279, 30), new Point(115, 0));
                DuiBaseControl msg = DuiBaseControlClass.AddDuiLabel(displaymsg, DuiBaseControlClass.Msgfont, new Size(130, 15), new Point(115, 30));
                InfomationControl.DUIControls.Clear();
                DuiBaseControl whitebg = DuiBaseControlClass.AddDuiLabel("", DuiBaseControlClass.Msgfont,
                    new Size(279, InfomationControl.Height - 80), new Point(0, 80));
                InfomationControl.DUIControls.Add(name);

                InfomationControl.DUIControls.Add(msg);
                whitebg.BackColor = Color.FromArgb(200, Color.White);
                InfomationControl.DUIControls.Add(whitebg);
                ToolsControl.Visible = true;
                this.Height = 260;
                #region 初始化第一行16*16工具栏

                ToolsControl.Controls.Clear();
                Bitmap[] btmBitmaps16 = new Bitmap[9]
                {
                    ZhuanResoures.nvip, ZhuanResoures.mvip, ZhuanResoures._17, ZhuanResoures._27, ZhuanResoures._37,
                    ZhuanResoures._47,
                    ZhuanResoures._57,
                    ZhuanResoures._67,
                    ZhuanResoures._77
                };
                Bitmap[] btmBitmaps2 = new Bitmap[6]
                {
                    Resources.weiyun, Resources.webqq_16, Resources.chongwu, Resources.music, Resources.qqgame_16,
                    Resources.chong
                };
                for (int i = 0; i < btmBitmaps16.Length - 1; i++)
                {
                    AddBottontoolItems16(btmBitmaps16[i + 1], new Size(20, 20), i, 0);

                }
                for (int i = 0; i < btmBitmaps2.Length - 1; i++)
                {
                    AddBottontoolItems16(btmBitmaps2[i + 1], new Size(20, 20), i, 1);

                }
                #endregion
            }));
            
        }

        public void AddBottontoolItems16(Bitmap btmBitmap,Size size, int index, int heightindex)
        {
            DuiBaseControl BottontoolItems = new DuiBaseControl();
            BottontoolItems.Size = size;
            BottontoolItems.Location = new Point(22 * index + 5, heightindex * 20 + 2);
            //vip.BackColor = Color.Transparent;
            BottontoolItems.BackgroundImage = btmBitmap;
            BottontoolItems.BackgroundImageLayout = ImageLayout.Center;
            BottontoolItems.MouseEnter += HightMouseEnter;
            BottontoolItems.MouseLeave += HightMouseLeave;
            ToolsControl.DUIControls.Add(BottontoolItems);
        }
        /// <summary>
        /// 鼠标离开控件时不显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HightMouseLeave(object sender, EventArgs e)
        {
            ((DuiBaseControl)sender).Borders.TopColor =
                ((DuiBaseControl)sender).Borders.BottomColor =
                    ((DuiBaseControl)sender).Borders.LeftColor =
                        ((DuiBaseControl)sender).Borders.RightColor = Color.Transparent;
        }
        /// <summary>
        ///  鼠标进入控件时高亮显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HightMouseEnter(object sender, EventArgs e)
        {

            ((DuiBaseControl)sender).Borders.TopColor =
                ((DuiBaseControl)sender).Borders.BottomColor =
                    ((DuiBaseControl)sender).Borders.LeftColor =
                        ((DuiBaseControl)sender).Borders.RightColor = Color.FromArgb(40, Color.Black);
        }
    }
}