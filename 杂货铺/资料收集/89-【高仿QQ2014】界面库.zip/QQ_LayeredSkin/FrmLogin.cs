﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using LayeredSkin.Controls;
using LayeredSkin.DirectUI;
using QQ_LayeredSkin.Menu;
using QQ_LayeredSkin.Properties;

namespace QQ_LayeredSkin
{
    public partial class FrmLogin : LayeredBaseForm
    {
        #region 构造函数
        public FrmLogin()
        {
            InitializeComponent();
            //线程直接控制UI。（建议使用委托）
            Control.CheckForIllegalCrossThreadCalls = false;
        } 
        #endregion

        #region 拖动无边框窗体

        /// <summary>
        /// 窗体鼠标按下事件（移动窗体）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MoveFormMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LayeredSkin.NativeMethods.MouseToMoveControl(this.Handle);
            }
        }
        #endregion

        #region 设置按钮 窗体翻转
        public bool isShow = false;
        bool isFirst = true;
        private void BtnSetClick(object sender, EventArgs e)
        {
            isShow = false;
            if (isFirst)
            {
                this.Animation.Effect = new LayeredSkin.Animations.ThreeDTurn();
                this.Animation.AnimationEnd += Animation_AnimationEnd;
            }
            isFirst = false;

            this.Animation.Asc = false;
            this.Animation.Start();
        }

        private FrmLoginSetting frmLoginSetting;
        void Animation_AnimationEnd(object sender, LayeredSkin.Animations.AnimationEventArgs e)
        {
            if (!isShow)
            {
                this.Hide();
                if (frmLoginSetting == null || frmLoginSetting.IsDisposed)
                {
                    frmLoginSetting = new FrmLoginSetting(this);
                }
                frmLoginSetting.Location = this.Location;
                frmLoginSetting.Show();
            }
        }
        void Animation_AnimationEndToFrmMain(object sender, LayeredSkin.Animations.AnimationEventArgs e)
        {
            this.Hide();
            FrmMain frmMain = new FrmMain();
            frmMain.Location = new Point(Screen.GetWorkingArea(this).Width-400,50);
            frmMain.Show();
        }
        #endregion

        #region 窗体加载事件
        private void Form1_Load(object sender, EventArgs e)
        {
            TxtUsername.Text = "";
            TxtPwd.Text = "";

            HeadImg.InnerDuiControl.BorderRender = new FilletBorderRender(6, 1, Color.SkyBlue);

            TxtUsername.BackgroundImage = Properties.Resources.txtId_NormlBack;
            TxtPwd.BackgroundImage = Properties.Resources.txtPwd_NormlBack;
            //加载状态图标
            DuiLabel state = new DuiLabel();
            state.BackgroundImage = Resources.imonline;
            state.BackgroundImageLayout = ImageLayout.Center;
            state.Size = new Size(15, 15);
            state.Location = new Point(63, 63);
            state.MouseEnter += HightMouseEnter;
            state.MouseLeave += HightMouseLeave;
            state.MouseDown += StateMenuMouseDown;
            HeadImg.DUIControls.Add(state);
        }

        #endregion

        #region 状态按钮事件
        /// <summary>
        /// 鼠标离开控件时不显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HightMouseLeave(object sender, EventArgs e)
        {
            ((DuiBaseControl)sender).Borders.TopColor =
                ((DuiBaseControl)sender).Borders.BottomColor =
                    ((DuiBaseControl)sender).Borders.LeftColor =
                        ((DuiBaseControl)sender).Borders.RightColor = Color.Transparent;
        }
        /// <summary>
        ///  鼠标进入控件时高亮显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HightMouseEnter(object sender, EventArgs e)
        {

            ((DuiBaseControl)sender).Borders.TopColor =
                ((DuiBaseControl)sender).Borders.BottomColor =
                    ((DuiBaseControl)sender).Borders.LeftColor =
                        ((DuiBaseControl)sender).Borders.RightColor = Color.FromArgb(40, Color.Black);
        }
        private void StateMenuMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                DuiBaseControl send = (DuiBaseControl)sender;
                this.contextMenuStrip1.Show(new Point(send.LocationToScreen.X, send.LocationToScreen.Y + send.Height));

            }
        }

        private void StatuItemsClick(object sender, EventArgs e)
        {
            HeadImg.DUIControls[0].BackgroundImage = ((ToolStripMenuItem)sender).Image;
        }

        #endregion

        #region 关闭、缩小按钮事件
        private void BtnMiniClick(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BtnCloseClick(object sender, EventArgs e)
        {
            this.Animation.Effect = new LayeredSkin.Animations.GradualCurtainEffect();
            //this.Animation.Asc = true;
            Close();
        }
        #endregion

        #region 账号密码框事件
        private void TxtUsername_MouseEnter(object sender, EventArgs e)
        {
            ((LayeredTextBox)sender).BackgroundImage = Properties.Resources.txtId_MouseBack;
        }

        private void TxtUsername_MouseLeave(object sender, EventArgs e)
        {
            ((LayeredTextBox)sender).BackgroundImage = Properties.Resources.txtId_NormlBack;
        }


        private void TxtPwd_MouseEnter(object sender, EventArgs e)
        {
            ((LayeredTextBox)sender).BackgroundImage = Properties.Resources.txtPwd_MouseBack;
        }

        private void TxtPwd_MouseLeave(object sender, EventArgs e)
        {
            ((LayeredTextBox)sender).BackgroundImage = Properties.Resources.txtPwd_NormlBack;
        }

        private void BtnKeyBoardClick(object sender, EventArgs e)
        {
            //PassKey pass = new PassKey(this.Left + TxtPwd.Left - 25, this.Top + TxtPwd.Bottom, TxtPwd);
            //pass.Show(this);
        }
        #endregion

        #region 登录按钮事件
        private void BtnLoginClick(object sender, EventArgs e)
        {
            BtnLogin.Enabled = false;
            this.BeginInvoke((MethodInvoker)delegate()
            {
                lblogininfo.Text = "";
                layeredPanel3.Visible = false;
                int oldleft = HeadImg.Left;
                int newleft = this.Width / 2 - HeadImg.Width / 2+16;
                for (int i = oldleft; i <= newleft; i ++)
                {
                    HeadImg.Left = i;
                    Application.DoEvents();
                    this.Refresh();
                }
                Application.DoEvents();
                this.Refresh();
                //3秒后进入主界面
                Thread.Sleep(1000);
                StartMain();
            });
        } 
        #endregion

        #region 启动主窗体加载动画
        public void StartMain()
        {
            this.Animation.Effect = new LayeredSkin.Animations.GradualCurtainEffect();
            this.Animation.AnimationEnd += Animation_AnimationEndToFrmMain;
            this.Animation.Asc = false;
            this.Animation.Start();
        } 
        #endregion

        public FrmUserList QFrmUserList = null;
        private void UserListShowDown(object sender, MouseEventArgs e)
        {
            #region 弹出菜单栏

            int left = TxtUsername.Location.X + this.Left + TxtUsername.Parent.Left;
            int top = TxtUsername.Location.Y + this.Top + TxtUsername.Parent.Top+TxtUsername.Height;
            //窗体的TopLeft值
            int UserTop = top;
            //int UserLeft = this.Left - 240 - 2;
            int UserLeft = left;
            //屏幕不包括任务栏的高度
            int PH = Screen.GetWorkingArea(this).Height;
            //判断是否超过屏幕高度
            if (UserTop < 0)
            {
                UserTop = 0;
            }

            int PW = Screen.GetWorkingArea(this).Width;
            //判断是否大于屏幕右边
            if (UserLeft + 260 > PW)
            {
                UserLeft = PW - 160;
            }
            //窗体不为空传值
            if (QFrmUserList != null)
            {
                if(QFrmUserList.IsDisposed)
                    QFrmUserList = new FrmUserList(TxtUsername, TxtPwd, HeadImg);
                QFrmUserList.Location = new Point(left-3 , UserTop );
            }
            else
            {
                QFrmUserList = new FrmUserList(TxtUsername,TxtPwd,HeadImg);
                QFrmUserList.Location = new Point(left-3, UserTop);
            }
            QFrmUserList.Width = TxtUsername.Width+6;
            QFrmUserList.Show();
            #endregion
        }
    }
}
