﻿namespace QQ_LayeredSkin
{
    partial class FrmUserinfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUserinfo));
            this.timShow = new System.Windows.Forms.Timer(this.components);
            this.QQShow = new LayeredSkin.Controls.LayeredPictureBox();
            this.InfomationControl = new LayeredSkin.Controls.LayeredBaseControl();
            this.ToolsControl = new LayeredSkin.Controls.LayeredBaseControl();
            this.SuspendLayout();
            // 
            // timShow
            // 
            this.timShow.Interval = 1000;
            this.timShow.Tick += new System.EventHandler(this.timShow_Tick);
            // 
            // QQShow
            // 
            this.QQShow.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("QQShow.BackgroundImage")));
            this.QQShow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.QQShow.Borders.BottomColor = System.Drawing.Color.White;
            this.QQShow.Borders.BottomWidth = 1;
            this.QQShow.Borders.LeftColor = System.Drawing.Color.White;
            this.QQShow.Borders.LeftWidth = 1;
            this.QQShow.Borders.RightColor = System.Drawing.Color.White;
            this.QQShow.Borders.RightWidth = 1;
            this.QQShow.Borders.TopColor = System.Drawing.Color.White;
            this.QQShow.Borders.TopWidth = 1;
            this.QQShow.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("QQShow.Canvas")));
            this.QQShow.Image = null;
            this.QQShow.Images = null;
            this.QQShow.Interval = 100;
            this.QQShow.Location = new System.Drawing.Point(8, 12);
            this.QQShow.MultiImageAnimation = false;
            this.QQShow.Name = "QQShow";
            this.QQShow.Size = new System.Drawing.Size(107, 175);
            this.QQShow.TabIndex = 5;
            this.QQShow.Text = "layeredPictureBox1";
            // 
            // InfomationControl
            // 
            this.InfomationControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.InfomationControl.Borders.BottomColor = System.Drawing.Color.Empty;
            this.InfomationControl.Borders.BottomWidth = 1;
            this.InfomationControl.Borders.LeftColor = System.Drawing.Color.Empty;
            this.InfomationControl.Borders.LeftWidth = 1;
            this.InfomationControl.Borders.RightColor = System.Drawing.Color.Empty;
            this.InfomationControl.Borders.RightWidth = 1;
            this.InfomationControl.Borders.TopColor = System.Drawing.Color.Empty;
            this.InfomationControl.Borders.TopWidth = 1;
            this.InfomationControl.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("InfomationControl.Canvas")));
            this.InfomationControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.InfomationControl.Location = new System.Drawing.Point(5, 5);
            this.InfomationControl.Name = "InfomationControl";
            this.InfomationControl.Size = new System.Drawing.Size(274, 208);
            this.InfomationControl.TabIndex = 6;
            this.InfomationControl.Text = "layeredBaseControl1";
            // 
            // ToolsControl
            // 
            this.ToolsControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ToolsControl.Borders.BottomColor = System.Drawing.Color.Empty;
            this.ToolsControl.Borders.BottomWidth = 1;
            this.ToolsControl.Borders.LeftColor = System.Drawing.Color.Empty;
            this.ToolsControl.Borders.LeftWidth = 1;
            this.ToolsControl.Borders.RightColor = System.Drawing.Color.Empty;
            this.ToolsControl.Borders.RightWidth = 1;
            this.ToolsControl.Borders.TopColor = System.Drawing.Color.Empty;
            this.ToolsControl.Borders.TopWidth = 1;
            this.ToolsControl.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("ToolsControl.Canvas")));
            this.ToolsControl.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ToolsControl.Location = new System.Drawing.Point(5, 213);
            this.ToolsControl.Name = "ToolsControl";
            this.ToolsControl.Size = new System.Drawing.Size(274, 43);
            this.ToolsControl.TabIndex = 4;
            this.ToolsControl.Text = "layeredBaseControl2";
            // 
            // FrmUserinfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.QQShow);
            this.Controls.Add(this.InfomationControl);
            this.Controls.Add(this.ToolsControl);
            this.Name = "FrmUserinfo";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Load += new System.EventHandler(this.FrmWeather_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timShow;
        private LayeredSkin.Controls.LayeredPictureBox QQShow;
        private LayeredSkin.Controls.LayeredBaseControl InfomationControl;
        public LayeredSkin.Controls.LayeredBaseControl ToolsControl;
    }
}