﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;
using LayeredSkin.Controls;
using LayeredSkin.DirectUI;
using QQ_LayeredSkin.Properties;

namespace QQ_LayeredSkin.Menu
{
    public partial class FrmUserList : LayeredBaseForm
    {
        private LayeredTextBox txtusername;
        private LayeredBaseControl headBaseControl;
        private LayeredTextBox txtpwd;
        private Font _font1 = new Font("微软雅黑", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
            ((byte)(134)));
        private Font _font2 = new Font("微软雅黑", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
            ((byte)(134)));
        public FrmUserList(LayeredTextBox txtBox1,LayeredTextBox txtBox2,LayeredBaseControl headbase)
        {
            InitializeComponent();
            txtusername = txtBox1;
            txtpwd = txtBox2;
            headBaseControl = headbase;
        }
        public FrmUserList()
        {
            InitializeComponent();
        }
        private void FrmMenu_Deactivate(object sender, EventArgs e)
        {
            this.Hide();
        }

        private DuiBaseControl BaseControl = null;

        private void FrmMenu_Load(object sender, EventArgs e)
        {
            ReadUserInfo();
        }

        public void ReadUserInfo()
        {
            layeredListBox1.Items.Add(AddChatItems(Resources.勾引, "BinGoo", "315567586"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._102, "蓝笔", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._114, "蓝笔1", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._136, "蓝笔2", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._137, "蓝笔3", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._138, "蓝笔4", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._144, "蓝笔5", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._149, "蓝笔6", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._83, "蓝笔7", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._161, "蓝笔8", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._36, "蓝笔9", "247009080"));
            layeredListBox1.Items.Add(AddChatItems(HeadResource._22, "蓝笔10", "247009080"));
            layeredListBox1.RefreshList();
        }

        public DuiBaseControl AddChatItems(Bitmap headimg,string nic,string qq)
        {
            //好友昵称
            DuiLabel niclb = DuiBaseControlClass.AddDuiLabel(string.Format("{0}", nic),
                DuiBaseControlClass.Msgfont, new Size(this.Width - 55, 20), new Point(30, 8));
            //好友QQ号
            DuiLabel qqlb = DuiBaseControlClass.AddDuiLabel(qq, DuiBaseControlClass.Msgfont, new Size(this.Width - 85, 20),
                    new Point(30, 30));
            //好友头像
            DuiBaseControl pic = DuiBaseControlClass.AddDuiBaseControl(headimg, ImageLayout.Stretch, Cursors.Default, new Size(22, 22),
                new Point(5, 5));
            pic.BackColor = Color.BurlyWood;
            DuiBaseControl closepci= DuiBaseControlClass.AddDuiBaseControl(Resources.page_close_btn_normal, ImageLayout.Stretch, Cursors.Default, new Size(25, 25),
                new Point(layeredListBox1.Width-30, 4));
            closepci.Cursor = Cursors.Hand;
            closepci.MouseClick += ItemsCloseMouseClic;
            closepci.MouseEnter += ItemsCloseMouseEnter;
            closepci.MouseLeave+= ItemsCloseMouseLeave;
            closepci.MouseDown += ItemsCloseMouseDown;
            closepci.MouseUp+= ItemsCloseMouseUp;
            closepci.Visible = false;
            //好友项容器
            DuiBaseControl item = new DuiBaseControl();
            item.BackColor = Color.Transparent;
            item.Width = layeredListBox1.Width-10;
            item.Height = 32;
            item.MouseUp += ItemsMouseUp;
            item.MouseEnter += ItemsMouseEnter;
            item.MouseLeave += ItemsMouseLeave;
            item.Controls.Add(niclb);
            item.Controls.Add(qqlb);
            item.Controls.Add(pic);
            item.Controls.Add(closepci);
            item.Name = this.layeredListBox1.Items.Count.ToString();
            item.Visible = true;

            return item;
        }
        public DuiBaseControl AddItems(string text,Font font,Point location,Size size,bool isEven)
        {
            DuiLabel duiLabel = new DuiLabel();
            duiLabel.Size = size;
            duiLabel.Text = text;
            duiLabel.TextAlign=ContentAlignment.MiddleLeft;
            duiLabel.Font = font;
            duiLabel.TextRenderMode = TextRenderingHint.AntiAliasGridFit;
            duiLabel.Location = location;

            //好友项容器
            DuiBaseControl item = new DuiBaseControl();
            item.BackColor = Color.Transparent;
            item.Size = size;
            if (isEven)
            {
                item.MouseEnter += ItemsMouseEnter;
                item.MouseLeave += ItemsMouseLeave;
            }
            item.Controls.Add(duiLabel);
            item.Name = this.layeredListBox1.Items.Count.ToString();
            item.Visible = true;
            return item;
        }

        #region 列表事件
        public int ItemsIndex = -1;
        /// <summary>
        /// 好友项点击选中时触发的事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseUp(object sender, MouseEventArgs e)
        {
            txtusername.Text = ((DuiLabel) layeredListBox1.Items[ItemsIndex].Controls[1]).Text;
            headBaseControl.BackgroundImage=((DuiBaseControl)layeredListBox1.Items[ItemsIndex].Controls[2]).
            BackgroundImage;
            this.layeredListBox1.RefreshList();
            this.Hide();
        }

        /// <summary>
        /// 好友项鼠标进入控件时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseEnter(object sender, EventArgs e)
        {
            //if (ItemsIndex == -1)
            //{
            //    return;
            //}
            int OldItemsIndex = ItemsIndex;
            ItemsIndex = int.Parse(((DuiBaseControl)sender).Name);
            int one = ItemsIndex - 2;
            int two = ItemsIndex - 1;
            int tree = ItemsIndex;
            int four = ItemsIndex + 1;
            int five = ItemsIndex + 2;

            if (one > -1)
            {
                layeredListBox1.Items[one].Height = 32;
                layeredListBox1.Items[one].Controls[0].Visible = false;
                layeredListBox1.Items[one].Controls[1].Location = new Point(30, 8);
                layeredListBox1.Items[one].Controls[2].Size = new Size(22, 22);
            }
            layeredListBox1.RefreshList();
            if (two > -1)
            {
                layeredListBox1.Items[two].Height = 45;
                layeredListBox1.Items[two].Controls[0].Visible = false;
                layeredListBox1.Items[two].Controls[1].Location = new Point(42, 10);
                layeredListBox1.Items[two].Controls[2].Size = new Size(35, 35);
            }
            layeredListBox1.RefreshList();
            layeredListBox1.Items[tree].Height = 53;
            layeredListBox1.Items[tree].Controls[0].Visible = true;
            layeredListBox1.Items[tree].Controls[0].Location = new Point(50, 7);
            layeredListBox1.Items[tree].Controls[1].Location = new Point(50, 28);
            layeredListBox1.Items[tree].Controls[2].Size = new Size(43, 43);
            ((DuiBaseControl)sender).Controls[3].Location = new Point(layeredListBox1.Width-50,14);
            layeredListBox1.RefreshList();
            if (four < layeredListBox1.Items.Count)
            {
                layeredListBox1.Items[four].Height = 45;
                layeredListBox1.Items[four].Controls[0].Visible = false;
                layeredListBox1.Items[four].Controls[1].Location = new Point(42, 10);
                layeredListBox1.Items[four].Controls[2].Size = new Size(35, 35);
            }
            layeredListBox1.RefreshList();
            if (five < layeredListBox1.Items.Count)
            {
                layeredListBox1.Items[five].Height = 32;
                layeredListBox1.Items[five].Controls[0].Visible = false;
                layeredListBox1.Items[five].Controls[1].Location = new Point(42, 10);
                layeredListBox1.Items[five].Controls[2].Size = new Size(22, 22);
            }
            layeredListBox1.RefreshList();
            ((DuiBaseControl)sender).Controls[1].ForeColor = Color.White;
            ((DuiBaseControl)sender).Controls[3].Visible = true;
            ((DuiBaseControl)sender).BackColor = Color.DodgerBlue;
            for (int i = 0; i < layeredListBox1.Items.Count; i++)
            {
                if (i != one && i != two && i != tree && i != four && i != five)
                {
                    layeredListBox1.Items[i].Height = 32;
                    layeredListBox1.Items[i].Controls[0].Visible = false;
                    layeredListBox1.Items[i].Controls[1].Location = new Point(30, 8);
                    layeredListBox1.Items[i].Controls[2].Size = new Size(22, 22);
                    layeredListBox1.RefreshList();
                }
            }
            layeredListBox1.RefreshList();
        }

        /// <summary>
        /// 好友项鼠标离开时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseLeave(object sender, EventArgs e)
        {
            if (this.Bounds.Contains(Cursor.Position))
            {
                //ItemsIndex = -1;
                ((DuiBaseControl) sender).Controls[1].ForeColor = Color.Black;
                ((DuiBaseControl) sender).BackColor = Color.Transparent;
                ((DuiBaseControl) sender).Controls[3].Visible = false;
                layeredListBox1.RefreshList();
            }
        }  
        #endregion

        private void ItemsCloseMouseEnter(object sender, EventArgs e)
        {
            if (ItemsIndex > -1)
            layeredListBox1.Items[ItemsIndex].Controls[3].BackgroundImage = Resources.page_close_btn_hover;
        }

        private void ItemsCloseMouseLeave(object sender, EventArgs e)
        {
            if (ItemsIndex > -1)
            layeredListBox1.Items[ItemsIndex].Controls[3].BackgroundImage = Resources.page_close_btn_normal;
        }
        private void ItemsCloseMouseDown(object sender, EventArgs e)
        {
            if(ItemsIndex > -1)
            layeredListBox1.Items[ItemsIndex].Controls[3].BackgroundImage = Resources.page_close_btn_click;
        }
        private void ItemsCloseMouseUp(object sender, EventArgs e)
        {
            if (ItemsIndex > -1)
            layeredListBox1.Items[ItemsIndex].Controls[3].BackgroundImage = Resources.page_close_btn_hover;
        }
        private void ItemsCloseMouseClic(object sender, EventArgs e)
        {
            int newname = ItemsIndex;
            layeredListBox1.Items.RemoveAt(ItemsIndex);
            for (int i = 0; i < layeredListBox1.Items.Count; i++)
            {
                layeredListBox1.Items[i].Height = 32;
                layeredListBox1.Items[i].Controls[0].Visible = false;
                layeredListBox1.Items[i].Controls[1].Location = new Point(30, 8);
                layeredListBox1.Items[i].Controls[2].Size = new Size(22, 22);
                layeredListBox1.Items[i].Controls[3].Visible = false;
                if (int.Parse(layeredListBox1.Items[i].Name) > newname)
                {
                    layeredListBox1.Items[i].Name = newname.ToString();
                    newname++;
                }
                layeredListBox1.RefreshList();
            }
            ItemsIndex = -1;
            //int h = 0;
            //if (layeredListBox1.Items.Count < 8)
            //{
            //    for (int i = 0; i < layeredListBox1.Items.Count; i++)
            //    {
            //        h += layeredListBox1.Items[i].Height;
            //    }
            //    this.Height = h + 3;
            //}
            
        }
    }
}
