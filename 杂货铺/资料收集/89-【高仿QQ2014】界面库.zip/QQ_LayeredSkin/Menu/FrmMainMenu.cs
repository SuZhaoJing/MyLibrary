﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;
using LayeredSkin.DirectUI;

namespace QQ_LayeredSkin.Menu
{
    public partial class FrmMainMenu : LayeredBaseForm
    {
        private Font _font1 = new Font("微软雅黑", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
            ((byte)(134)));
        private Font _font2 = new Font("微软雅黑", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
            ((byte)(134)));
        public FrmMainMenu()
        {
            InitializeComponent();
        }
        private void FrmMenu_Deactivate(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void FrmMenu_Load(object sender, EventArgs e)
        {
            this.Height = 346;
            this.Width = 240;
            layeredListBox1.Items.Add(AddItems("传文件到手机", _font1, new Point(0, 0), new Size(240, 40), true));
            layeredListBox1.Items.Add(AddItems("导出手机相册", _font1, new Point(0, 0), new Size(240, 40), true));
            layeredListBox1.Items.Add(AddItems("我的收藏", _font1, new Point(0, 0), new Size(240, 40), true));
            DuiBaseControl lineControl = new DuiBaseControl();
            lineControl.Size = new Size(220, 1);
            lineControl.BackColor = Color.LightGray;
            layeredListBox1.Items.Add(lineControl);
            layeredListBox1.Items.Add(AddItems("所有服务", _font2, new Point(5, 0), new Size(240, 30), true));
            layeredListBox1.Items.Add(AddItems("QQ会员", _font2, new Point(5, 0), new Size(240, 30), true));
            layeredListBox1.Items.Add(AddItems("工具", _font2, new Point(5, 0), new Size(240, 30), true));
            layeredListBox1.Items.Add(AddItems("安全", _font2, new Point(5, 0), new Size(240, 30), true));
            layeredListBox1.Items.Add(AddItems("帮助", _font2, new Point(5, 0), new Size(240, 30), true));
            layeredListBox1.Items.Add(AddItems("安全", _font2, new Point(5, 0), new Size(240, 30), true));
            DuiBaseControl baseControl=new DuiBaseControl();
            baseControl.Size = new Size(240, 35);
            baseControl.BackColor = Color.Gainsboro;
            DuiLabel lb = DuiBaseControlClass.AddDuiLabel("修改密码", _font2, new Size(60, 35), new Point(5, 0));
            lb.TextAlign = ContentAlignment.MiddleCenter;
            lb.ForeColor = Color.CornflowerBlue;
            lb.Cursor = Cursors.Hand;
            baseControl.Controls.Add(lb);
            lb = DuiBaseControlClass.AddDuiLabel("切换账号", _font2, new Size(60, 35), new Point(95, 0));
            lb.TextAlign = ContentAlignment.MiddleCenter;
            lb.ForeColor = Color.CornflowerBlue;
            lb.Cursor = Cursors.Hand;
            baseControl.Controls.Add(lb);
            lb = DuiBaseControlClass.AddDuiLabel("退出", _font2, new Size(60, 35), new Point(165, 0));
            lb.TextAlign = ContentAlignment.MiddleCenter;
            lb.ForeColor = Color.CornflowerBlue;
            lb.Cursor = Cursors.Hand;
            baseControl.Controls.Add(lb);
            layeredListBox1.Items.Add(baseControl);
            layeredListBox1.RefreshList();
        }

        public DuiBaseControl AddItems(string text,Font font,Point location,Size size,bool isEven)
        {
            DuiLabel duiLabel = new DuiLabel();
            duiLabel.Size = size;
            duiLabel.Text = text;
            duiLabel.TextAlign=ContentAlignment.MiddleLeft;
            duiLabel.Font = font;
            duiLabel.TextRenderMode = TextRenderingHint.AntiAliasGridFit;
            duiLabel.Location = location;

            //好友项容器
            DuiBaseControl item = new DuiBaseControl();
            item.BackColor = Color.Transparent;
            item.Size = size;
            if (isEven)
            {
                item.MouseEnter += ItemsMouseEnter;
                item.MouseLeave += ItemsMouseLeave;
            }
            item.Controls.Add(duiLabel);
            item.Name = this.layeredListBox1.Items.Count.ToString();
            item.Visible = true;
            return item;
        }

        /// <summary>
        /// 好友项鼠标进入控件时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseEnter(object sender, EventArgs e)
        {
            ((DuiBaseControl) sender).Controls[0].ForeColor = Color.White;
            ((DuiBaseControl) sender).BackColor = Color.DarkBlue;
        }
        /// <summary>
        /// 好友项鼠标离开时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseLeave(object sender, EventArgs e)
        {
            ((DuiBaseControl)sender).Controls[0].ForeColor = Color.Black;
            ((DuiBaseControl) sender).BackColor = Color.Transparent;
        } 
    }
}
