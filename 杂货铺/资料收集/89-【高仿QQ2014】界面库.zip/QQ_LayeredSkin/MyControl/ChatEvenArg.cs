﻿/********************************************************************
 * *
 * * Copyright (C) 2013-? Corporation All rights reserved.
 * * 作者： BinGoo QQ：315567586 
 * * 请尊重作者劳动成果，请保留以上作者信息，禁止用于商业活动。
 * *
 * * 创建时间：2014-08-05
 * * 说明：
 * *
********************************************************************/
using LayeredSkin.DirectUI;

namespace QQ.Controls
{
    public class ChatListEventArgs
    {
        private DuiBaseControl headBaseControl;
        public DuiBaseControl HeadBaseControl
        {
            get { return headBaseControl; }
        }

        private DuiBaseControl selectItem;
        public DuiBaseControl SelectItem
        {
            get { return selectItem; }
        }

        /// <summary>
        /// 悬浮事件
        /// </summary>
        /// <param name="mouseonhead">鼠标上所悬浮的好友</param>
        /// <param name="selectsubitem">选中的好友</param>
        public ChatListEventArgs(DuiBaseControl mouseonhead, DuiBaseControl selectitem)
        {
            this.headBaseControl = mouseonhead;
            this.selectItem = selectitem;
        }
    }

    public class ChatListClickEventArgs
    {
        private DuiBaseControl _selectChatItem;
        /// <summary>
        /// 选中的好友项
        /// </summary>
        public DuiBaseControl SelectChatItem
        {
            get { return _selectChatItem; }
        }

        public TagFrirendInfo Friendinformation
        {
            get { return _selectChatItem.Tag == null ? null : (TagFrirendInfo)_selectChatItem.Tag; }
            set { _selectChatItem.Tag = Friendinformation; }
        }
        /// <summary>
        /// 选中事件
        /// </summary>
        /// <param name="selectsubitem">选中的好友项</param>
        public ChatListClickEventArgs(DuiBaseControl selectsubitem)
        {
            this._selectChatItem = selectsubitem;
            if (selectsubitem.Tag != null)
                Friendinformation = (TagFrirendInfo)selectsubitem.Tag;
        }
    }
}
