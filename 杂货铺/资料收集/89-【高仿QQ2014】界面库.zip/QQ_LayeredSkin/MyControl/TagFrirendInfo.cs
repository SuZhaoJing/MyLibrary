﻿/********************************************************************
 * *
 * * Copyright (C) 2013-? Corporation All rights reserved.
 * * 作者： BinGoo QQ：315567586 
 * * 请尊重作者劳动成果，请保留以上作者信息，禁止用于商业活动。
 * *
 * * 创建时间：2014-08-05
 * * 说明：
 * *
********************************************************************/

using System.Drawing;

namespace QQ.Controls
{
    /// <summary>
    /// 好友详细信息公共类
    /// </summary>
    public class TagFrirendInfo
    {
        /// <summary>
        /// 用户UIN（非QQ号）
        /// </summary>
        public string Uin { get; set; }
        /// <summary>
        /// 用户备注名称
        /// </summary>
        public string MarkName { get; set; }
        /// <summary>
        /// 用户昵称
        /// </summary>
        public string NicName { get; set; }
        /// <summary>
        /// 用户个人消息（用于标记QQ空间动态更新）
        /// </summary>
        public string PersonalMsg { get; set; }
        /// <summary>
        /// 个性用户签名
        /// </summary>
        public string Sign { get; set; }
        /// <summary>
        /// 用户头像
        /// </summary>
        public Bitmap HeadImg { get; set; }
        /// <summary>
        /// 是否有新消息
        /// </summary>
        public string IsHaveMsg { get; set; }
        /// <summary>
        /// 用户QQ号
        /// </summary>
        public string QQ { get; set; }
        public string FlagStatus { get; set; }
        /// <summary>
        /// 客户端类型
        /// </summary>
        public string ClientType { get; set; }

        /// <summary>
        /// 是否是vip
        /// </summary>
        public string IsVip { get; set; }
        /// <summary>
        /// Vip等级
        /// </summary>
        public string VipLv { get; set; }
    }

    public class TagGroupInfo
    {
        /// <summary>
        /// 分组名
        /// </summary>
        public int Name { get; set; }

        /// <summary>
        /// 在线用户数
        /// </summary>
        public int OnLineCount { get; set; }

        /// <summary>
        /// 所有用户数
        /// </summary>
        public int ItemsCount { get; set; }

        /// <summary>
        /// 展开收缩状态
        /// </summary>
        public string OpenCloseStyle { get; set; }
    }
}
