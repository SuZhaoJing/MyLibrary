﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;
using LayeredSkin.Controls;
using LayeredSkin.DirectUI;
using QQ_LayeredSkin.Properties;

namespace QQ.Controls
{
    public partial class LayeredChatListBox : LayeredListBox
    {
        #region 构造函数
        public LayeredChatListBox()
        {
            InitializeComponent();
        } 
        #endregion

        #region 变量

        /// <summary>
        /// 全局DuiBaseControl控件申明（重复利用）
        /// </summary>
        private DuiBaseControl _baseControl;

        /// <summary>
        /// 选中的好友项ID(为选中为-1)
        /// </summary>
        public int ItemsIndex = -1;

        private Font _font = new Font("微软雅黑", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
            ((byte) (134)));

        #endregion

        #region 属性
        /// <summary>
        /// 是否显示小头像
        /// </summary>
        private  bool _isSmallHead = false;
        public bool IsSmallHead {
            get { return _isSmallHead; }
            set { _isSmallHead = value; }
        }

        /// <summary>
        /// 分组项鼠标进入时的颜色
        /// </summary>
        private Color _groupMouseEnterBackColor = Color.FromArgb(255, 236, 242, 246);
        public Color GroupMouseEnterBackColor
        {
            get { return _groupMouseEnterBackColor; }
            set { _groupMouseEnterBackColor = value; }
        }
        /// <summary>
        /// 分组项鼠标离开时的颜色
        /// </summary>
        private Color _groupMouseLeaveBackColor = Color.FromArgb(255, 230, 233, 240);
        public Color GroupMouseLeaveBackColor
        {
            get { return _groupMouseLeaveBackColor; }
            set { _groupMouseLeaveBackColor = value; }
        }
        /// <summary>
        /// 好友项鼠标离开时的颜色
        /// </summary>
        private Color _itemNomalBackColor = Color.Transparent;
        public Color ItemNomalBackColor {
            get { return _itemNomalBackColor; }
            set { _itemNomalBackColor=value; }
        }
        /// <summary>
        /// 好友项鼠标移动到上面时的颜色
        /// </summary>
        private Color _itemMoveBackColor = Color.FromArgb(120, 252, 240, 193);
        public Color ItemMoveBackColor
        {
            get { return _itemMoveBackColor; }
            set { _itemMoveBackColor = value; }
        }
        /// <summary>
        /// 好友项选中时的颜色
        /// </summary>
        private Color _itemSelectBackColor = Color.FromArgb(255, 252, 240, 193);
        public Color ItemSelectBackColor
        {
            get { return _itemSelectBackColor; }
            set { _itemSelectBackColor = value; }
        }
        #endregion

        #region 方法

        /// <summary>
        /// 添加好友列表项
        /// </summary>
        /// <param name="tagfrirendInfo">好友信息类</param>
        /// <returns></returns>
        public DuiBaseControl AddChatItems(TagFrirendInfo tagfrirendInfo)
        {
            DuiLabel markname;
            //好友项的名称
            if (tagfrirendInfo.MarkName == "")
            {
                markname = IsSmallHead
                    ? AddDuiLabel(string.Format("{0}", tagfrirendInfo.NicName), _font,
                        new Size(this.Width - 55, 20), new Point(40, 8),
                        false)
                    : AddDuiLabel(string.Format("{0}", tagfrirendInfo.NicName), _font,
                        new Size(this.Width - 85, 20), new Point(55, 8),
                        false);
            }
            else
            {
                markname = IsSmallHead
                    ? AddDuiLabel(string.Format("{0}  ({1})", tagfrirendInfo.MarkName, tagfrirendInfo.NicName),
                        _font, new Size(this.Width - 55, 20), new Point(40,8),
                        false)
                    : AddDuiLabel(string.Format("{0}  ({1})", tagfrirendInfo.MarkName, tagfrirendInfo.NicName),
                        _font, new Size(this.Width - 85, 20), new Point(55, 8),
                        false);
            }

            if (tagfrirendInfo.IsVip == "1")
            {
                markname.ForeColor = Color.Red;
            }
            //好友动态信息
            DuiLabel info = IsSmallHead
                ? AddDuiLabel(tagfrirendInfo.Sign, _font, new Size(this.Width - 85, 20),
                    new Point(40, 30),
                    false)
                : AddDuiLabel(tagfrirendInfo.Sign, _font, new Size(this.Width - 85, 20),
                    new Point(55, 30),
                    false);
            info.ForeColor = Color.FromArgb(60, 60, 60);
            //好友头像
            DuiBaseControl pic = AddItemsHeadImgControll(tagfrirendInfo.HeadImg , ImageLayout.Stretch, Cursors.Default,
                IsSmallHead
                ? new Size(25, 25):new Size(45, 45),
                new Point(5, 5), true);
            pic.BackColor = Color.BurlyWood;

            //好友项容器
            DuiBaseControl item = new DuiBaseControl();
            item.BackColor = ItemNomalBackColor;
            item.Width = 900;
            item.Height = IsSmallHead
                ? 30:55;
            item.MouseUp += ItemsMouseUp;
            item.MouseDoubleClick+=ItemsDoubleClick;
            item.MouseEnter += ItemsMouseEnter;
            item.MouseLeave += ItemsMouseLeave;
            item.Controls.Add(markname);
            item.Controls.Add(info);
            item.Controls.Add(pic);
            item.Name = this.Items.Count.ToString();
            item.Visible = false;

            return item;
        }

        /// <summary>
        /// 好友信息类封装成object
        /// </summary>
        /// <param name="headBitmap"></param>
        /// <param name="nic"></param>
        /// <param name="markName"></param>
        /// <param name="sign"></param>
        /// <param name="qq"></param>
        /// <param name="isonline"></param>
        /// <param name="isvip"></param>
        /// <returns></returns>
        public TagFrirendInfo GetObj(Bitmap headBitmap,string nic,string markName,string sign,string qq,string isonline,string isvip)
        {
            TagFrirendInfo tag = new TagFrirendInfo();
            tag.HeadImg = headBitmap;
            tag.NicName = nic;
            tag.Sign = sign;
            tag.QQ =qq;
            tag.MarkName = markName;
            tag.FlagStatus =isonline;
            tag.IsVip = isvip;
            return tag;
        }
        /// <summary>
        /// 返回DuiBaseControl
        /// </summary>
        /// <param name="bitmap">DuiBaseControl的背景图片</param>
        /// <param name="layout">DuiBaseControl的背景图片显示样式</param>
        /// <param name="cursor">鼠标样式</param>
        /// <param name="size">大小</param>
        /// <param name="location">显示位置</param>
        /// <param name="isEven">是否有鼠标事件</param>
        /// <returns>返回_baseControl</returns>
        public DuiBaseControl AddDuiBaseControl(Bitmap bitmap, ImageLayout layout, Cursor cursor, Size size,
            Point location, bool isEven)
        {
            _baseControl = new DuiBaseControl();
            _baseControl.Size = size;
            _baseControl.Cursor = cursor;
            _baseControl.Location = location;
            _baseControl.BackColor = Color.Transparent;
            //baseControl.BorderRender = new FilletBorderRender(6, 2, Color.DodgerBlue);
            _baseControl.BackgroundImage = bitmap;
            _baseControl.BackgroundImageLayout = layout;
            if (isEven)
            {
                _baseControl.MouseEnter += HightMouseEnter;
                _baseControl.MouseLeave += HightMouseLeave;
            }
            return _baseControl;
        }

        /// <summary>
        /// 好友头像image
        /// </summary>
        /// <param name="bitmap">头像图片</param>
        /// <param name="layout">头像图片显示样式</param>
        /// <param name="cursor">鼠标滑过头像图片样式</param>
        /// <param name="size">头像图片大小</param>
        /// <param name="location">头像图片在父容器中的位置</param>
        /// <param name="isEven">鼠标滑过头像图片是否有鼠标的enter和leaver事件</param>
        /// <param name="isonline">是否在线</param>
        /// <returns></returns>
        public DuiBaseControl AddItemsHeadImgControll(Bitmap bitmap, ImageLayout layout, Cursor cursor, Size size,
            Point location, bool isEven)
        {
            _baseControl = new DuiBaseControl();
            _baseControl.Size = size;
            _baseControl.Cursor = cursor;
            _baseControl.Location = location;
            _baseControl.BackColor = Color.Transparent;
            //baseControl.BorderRender = new FilletBorderRender(6, 2, Color.DodgerBlue);
            _baseControl.BackgroundImage = bitmap;

            _baseControl.BackgroundImageLayout = layout;
            if (isEven)
            {
                _baseControl.MouseEnter += HeadImgMouseEnter;
                _baseControl.MouseLeave += HeadImgMouseLeave;
            }
            return _baseControl;
        }

        /// <summary>
        /// 好友列表信息label
        /// </summary>
        /// <param name="text">显示的信息内容</param>
        /// <param name="font">字体</param>
        /// <param name="size">大小</param>
        /// <param name="location">在父容器中的位置</param>
        /// <param name="isEven">鼠标滑过是否有鼠标的enter和leaver事件</param>
        /// <returns></returns>
        public DuiLabel AddDuiLabel(string text, Font font, Size size, Point location, bool isEven)
        {
            DuiLabel duiLabel = new DuiLabel();
            duiLabel.Size = size;
            duiLabel.Text = text;
            duiLabel.Font = font;
            duiLabel.TextRenderMode = TextRenderingHint.AntiAliasGridFit;
            duiLabel.Location = location;
            if (isEven)
            {
                duiLabel.MouseEnter += HightMouseEnter;
                duiLabel.MouseLeave += HightMouseLeave;
            }
            return duiLabel;
        }

        /// <summary>
        /// 添加好友组名
        /// </summary>
        /// <param name="groupName"></param>
        /// <param name="openOrclose"></param>
        /// <param name="itemsCount"></param>
        /// <param name="onlineCount"></param>
        /// <returns></returns>
        public DuiLabel AddChatGroup(string groupName, string openOrclose, int itemsCount, int onlineCount)
        {
            string groupname = "    " + groupName + string.Format("{0}/{1}", onlineCount, itemsCount);
            DuiLabel group = AddDuiLabel(groupname, _font, new Size(this.Width - 85, 25), new Point(0, 0),
                false);
            group.TextRenderMode = TextRenderingHint.ClearTypeGridFit;
            group.TextAlign = ContentAlignment.TopLeft;
            group.TextPadding = 3;
            //dui.TextRenderMode=System.Drawing.Text.TextRenderingHint.AntiAlias;
            group.BackgroundImageLayout = ImageLayout.None;
            group.BackColor = GroupMouseLeaveBackColor;
            group.BackgroundImage = Resources.list_right;
            group.Width = 900;
            group.Height = 25;
            group.Name = this.Items.Count.ToString();

            TagGroupInfo tag = new TagGroupInfo();
            tag.OpenCloseStyle = openOrclose;
            tag.ItemsCount = itemsCount;
            tag.OnLineCount = onlineCount;
            group.Tag = tag;
            group.MouseUp += FriendGroupMouseUp;
            //dui.MouseClick += dui_MouseClick;
            group.MouseEnter += GroupMouseEnter;
            group.MouseLeave += GroupMouseLeave;
            return group;
        }
        public DuiLabel AddGroupGroup(string groupName, string openOrclose, int itemsCount)
        {
            string groupname = "    " + groupName + string.Format("{0}", itemsCount);
            DuiLabel group = AddDuiLabel(groupname, _font, new Size(this.Width - 85, 25), new Point(0, 0),
                false);
            group.TextRenderMode = TextRenderingHint.ClearTypeGridFit;
            group.TextAlign = ContentAlignment.TopLeft;
            group.TextPadding = 3;
            //dui.TextRenderMode=System.Drawing.Text.TextRenderingHint.AntiAlias;
            group.BackgroundImageLayout = ImageLayout.None;
            group.BackColor = GroupMouseLeaveBackColor;
            group.BackgroundImage = Resources.list_right;
            group.Width = 900;
            group.Height = 25;
            group.Name = this.Items.Count.ToString();

            TagGroupInfo tag = new TagGroupInfo();
            tag.OpenCloseStyle = openOrclose;
            tag.ItemsCount = itemsCount;
            tag.OnLineCount = itemsCount;
            group.Tag = tag;
            group.MouseUp += FriendGroupMouseUp;
            //dui.MouseClick += dui_MouseClick;
            group.MouseEnter += GroupMouseEnter;
            group.MouseLeave += GroupMouseLeave;
            return group;
        }
        #region DuiBaseControl鼠标Enter和Leaver高亮显示和隐藏边框

        /// <summary>
        /// 鼠标离开控件时不显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HightMouseLeave(object sender, EventArgs e)
        {
            ((DuiBaseControl) sender).Borders.TopColor =
                ((DuiBaseControl) sender).Borders.BottomColor =
                    ((DuiBaseControl) sender).Borders.LeftColor =
                        ((DuiBaseControl) sender).Borders.RightColor = Color.Transparent;
        }

        /// <summary>
        ///  鼠标进入控件时高亮显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HightMouseEnter(object sender, EventArgs e)
        {

            ((DuiBaseControl) sender).Borders.TopColor =
                ((DuiBaseControl) sender).Borders.BottomColor =
                    ((DuiBaseControl) sender).Borders.LeftColor =
                        ((DuiBaseControl) sender).Borders.RightColor = Color.FromArgb(40, Color.Black);
        }

        /// <summary>
        /// 鼠标离开头像控件时不显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HeadImgMouseLeave(object sender, EventArgs e)
        {
            OnMouseLeaveHead(new ChatListEventArgs((DuiBaseControl) sender,
                (DuiBaseControl) ((DuiBaseControl) sender).Parent));
        }

        /// <summary>
        ///  鼠标进入头像控件时高亮显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HeadImgMouseEnter(object sender, EventArgs e)
        {
            OnMouseEnterHead(new ChatListEventArgs((DuiBaseControl) sender,
                (DuiBaseControl) ((DuiBaseControl) sender).Parent));
        }

        #endregion

        public void FreshItems()
        {
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].Controls.Count > 1)
                {
                    if (IsSmallHead)
                    {
                        if (ItemsIndex != int.Parse(Items[i].Name))
                        {
                            Items[i].Height = 30;
                            Items[i].Controls[0].Location = new Point(40, 8);
                            Items[i].Controls[1].Location = new Point(40, 30);
                            Items[i].Controls[2].Size = new Size(25, 25);
                        }
                    }
                    else
                    {
                        Items[i].Height = 55;
                        Items[i].Controls[0].Location = new Point(60, 8);
                        Items[i].Controls[1].Location = new Point(60, 30);
                        Items[i].Controls[2].Size = new Size(45, 45);
                    }
                }
            }
        }

        #endregion

        #region 事件

        #region 分组项事件

        /// <summary>
        /// 分组项鼠标弹起时触发的时间（鼠标单击事件）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FriendGroupMouseUp(object sender, MouseEventArgs e)
        {
            TagGroupInfo obj = (TagGroupInfo)((DuiBaseControl)sender).Tag;
            int id = Convert.ToInt32(((DuiBaseControl) sender).Name);

            if (obj.OpenCloseStyle == "open")
            {
                obj.OpenCloseStyle = "close";
                ((DuiBaseControl) sender).Tag = obj;
                for (int i = id + 1; i <= obj.ItemsCount+ id; i++)
                {
                    try
                    {
                        this.Items[i].Visible = false;
                    }
                    catch
                    {
                    }
                }
                ((DuiBaseControl) sender).BackgroundImage = Resources.list_right;
                this.RefreshList();
            }
            else
            {
                obj.OpenCloseStyle = "open";
                ((DuiBaseControl) sender).Tag = obj;

                for (int i = id + 1; i <= obj.ItemsCount + id; i++)
                {
                    try
                    {
                        this.Items[i].Visible = true;
                    }
                    catch
                    {
                    }
                }
                ((DuiBaseControl) sender).BackgroundImage = Resources.list_down;
                this.RefreshList();
            }

        }

        #region 分组项鼠标Enter和Leave事件
        /// <summary>
        /// 分组项鼠标离开控件时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GroupMouseLeave(object sender, EventArgs e)
        {
            ((DuiBaseControl)sender).BackColor = GroupMouseLeaveBackColor;
        }

        /// <summary>
        /// 分组项鼠标进入控件时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GroupMouseEnter(object sender, EventArgs e)
        {
            ((DuiBaseControl)sender).BackColor = GroupMouseEnterBackColor;
        }

        #endregion

        #endregion

        #region 好友列表项事件

        private void ItemsDoubleClick(object sender, MouseEventArgs e)
        {
            OnItemDoubleClickItem(new ChatListClickEventArgs((DuiBaseControl)sender),e);
        }

        /// <summary>
        /// 好友项点击选中时触发的事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseUp(object sender, MouseEventArgs e)
        {
            if (ItemsIndex > 0)
            {
                Items[ItemsIndex].BackColor = ((DuiBaseControl) sender).BackColor = ItemNomalBackColor;
                //如果是小头像则使用选中列表放大，其他项缩小
                if (IsSmallHead)
                {
                    Items[ItemsIndex].Height = 30;
                    Items[ItemsIndex].Controls[0].Location = new Point(40, 8);
                    Items[ItemsIndex].Controls[1].Location = new Point(40, 30);
                    Items[ItemsIndex].Controls[2].Size = new Size(25, 25);
                }
            }
            ItemsIndex = int.Parse(((DuiBaseControl) sender).Name);
            Items[ItemsIndex].BackColor = ItemSelectBackColor;
            if (IsSmallHead)
            {
                Items[ItemsIndex].Height = 55;
                Items[ItemsIndex].Controls[0].Location = new Point(60, 8);
                Items[ItemsIndex].Controls[1].Location = new Point(60, 30);
                Items[ItemsIndex].Controls[2].Size = new Size(45, 45);
            }
            this.RefreshList();
        }

        /// <summary>
        /// 好友项鼠标进入控件时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseEnter(object sender, EventArgs e)
        {
            if (ItemsIndex != int.Parse(((DuiBaseControl)sender).Name))
            {
                ((DuiBaseControl)sender).BackColor = ItemMoveBackColor;
            }
        }

        /// <summary>
        /// 好友项鼠标离开时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseLeave(object sender, EventArgs e)
        {
            if (ItemsIndex != int.Parse(((DuiBaseControl) sender).Name))
            {
                ((DuiBaseControl)sender).BackColor = ItemNomalBackColor;
            }
        } 

        #endregion

        #endregion

        #region 用户自定义事件

        public delegate void ChatHeadEventHandler(object sender, ChatListEventArgs e);

        public delegate void ChatListEventHandler(object sender, ChatListClickEventArgs e, MouseEventArgs es);

        [Description("用鼠标双击子项时发生")]
        [Category("子项操作")]
        public event ChatListEventHandler DoubleClickItem;

        [Description("在鼠标进入子项中的头像时发生")]
        [Category("子项操作")]
        public event ChatHeadEventHandler MouseEnterHead;

        [Description("在鼠标离开子项中的头像时发生")]
        [Category("子项操作")]
        public event ChatHeadEventHandler MouseLeaveHead;


        protected virtual void OnMouseEnterHead(ChatListEventArgs e)
        {
            if (this.MouseEnterHead != null)
                MouseEnterHead(this, e);
        }

        protected virtual void OnMouseLeaveHead(ChatListEventArgs e)
        {
            if (this.MouseLeaveHead != null)
                MouseLeaveHead(this, e);
        }

        protected virtual void OnItemDoubleClickItem(ChatListClickEventArgs e, MouseEventArgs es)
        {
            if (this.DoubleClickItem != null)
                DoubleClickItem(this, e, es);
        }

        #endregion
    }


}
