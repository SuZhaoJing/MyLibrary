﻿using System;

using System.Drawing;
using System.Windows.Forms;

namespace QQ_LayeredSkin
{
    public partial class FrmWeather : LayeredBaseForm
    {
        private Point point;
        public bool IsOpen = false;
        public FrmWeather(Point p)
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
            this.point = p;
        }
        #region 窗体位置

        private Point loactionPoint;

        public Point LoactionPoint
        {
            get
            {
                return loactionPoint;
            }
            set
            {
                loactionPoint = value;
            }
        }

        public void SetLoaction(Point _Point)
        {
            this.Location = _Point;
        }

        #endregion

        private void timShow_Tick(object sender, EventArgs e)
        {
            if (this.Bounds.Contains(Cursor.Position) || IsOpen)
            {
                this.Show();
            }
            //鼠标不在窗体内时
            else if (!this.Bounds.Contains(Cursor.Position) && (!IsOpen))
            {
                this.BeginInvoke((MethodInvoker) delegate()
                {
                    this.Animation.Effect = new LayeredSkin.Animations.RotateZoomEffect();
                    this.Close();
                    timShow.Enabled = false;
                });
            }

        }

        public void TimShow(bool flag)
        {
            this.Show();
            timShow.Enabled = flag;
        }

        private void FrmWeather_Load(object sender, EventArgs e)
        {
            
        }
    }
}
