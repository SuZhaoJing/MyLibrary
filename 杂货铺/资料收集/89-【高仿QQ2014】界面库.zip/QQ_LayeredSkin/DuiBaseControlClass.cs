﻿/********************************************************************
 * *
 * * Copyright (C) 2013-? Corporation All rights reserved.
 * * 作者： BinGoo QQ：315567586 
 * * 请尊重作者劳动成果，请保留以上作者信息，禁止用于商业活动。
 * *
 * * 创建时间：2014-08-05
 * * 说明：
 * *
********************************************************************/
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;
using LayeredSkin.DirectUI;

namespace QQ_LayeredSkin
{
    public static class DuiBaseControlClass
    {
        public static Font Titlefont = new Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
            ((byte)(134)));
        public static Font Msgfont = new Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
          ((byte)(134)));
        /// <summary>
        /// 返回DuiLabel
        /// </summary>
        /// <param name="text">显示的信息</param>
        /// <param name="font">字体</param>
        /// <param name="size">大小</param>
        /// <param name="location">显示位置</param>
        /// <returns></returns>
        public static  DuiLabel AddDuiLabel(string text, Font font, Size size, Point location)
        {
            DuiLabel duiLabel = new DuiLabel();
            duiLabel.Size = size;
            duiLabel.Text = text;
            duiLabel.Font = font;
            duiLabel.TextRenderMode = TextRenderingHint.AntiAliasGridFit;
            duiLabel.Location = location;
            return duiLabel;
        }
        /// <summary>
        /// 返回DuiBaseControl
        /// </summary>
        /// <param name="bitmap">DuiBaseControl的背景图片</param>
        /// <param name="layout">DuiBaseControl的背景图片显示样式</param>
        /// <param name="cursor">鼠标样式</param>
        /// <param name="size">大小</param>
        /// <param name="location">显示位置</param>
        /// <param name="isEven">是否有鼠标事件</param>
        /// <returns>返回_baseControl</returns>
        public static DuiBaseControl AddDuiBaseControl(Bitmap bitmap, ImageLayout layout, Cursor cursor, Size size,
            Point location)
        {
            DuiBaseControl _baseControl = new DuiBaseControl();
            _baseControl.Size = size;
            _baseControl.Cursor = cursor;
            _baseControl.Location = location;
            _baseControl.BackColor = Color.Transparent;
            //baseControl.BorderRender = new FilletBorderRender(6, 2, Color.DodgerBlue);
            _baseControl.BackgroundImage = bitmap;
            _baseControl.BackgroundImageLayout = layout;
            return _baseControl;
        }
    }
}
