﻿namespace QQ_LayeredSkin
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.在线ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.隐身ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.q我吧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.离开ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.忙碌ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.请勿打扰ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.离线ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.layeredDragBar3 = new LayeredSkin.Controls.LayeredDragBar();
            this.layeredDragBar4 = new LayeredSkin.Controls.LayeredDragBar();
            this.layeredDragBar1 = new LayeredSkin.Controls.LayeredDragBar();
            this.layeredDragBar2 = new LayeredSkin.Controls.LayeredDragBar();
            this.HeadBaseControl = new LayeredSkin.Controls.LayeredBaseControl();
            this.BaseControlWeather = new LayeredSkin.Controls.LayeredBaseControl();
            this.BtnSearch = new LayeredSkin.Controls.LayeredButton();
            this.TxtSearch = new LayeredSkin.Controls.LayeredTextBox();
            this.layeredButton2 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton1 = new LayeredSkin.Controls.LayeredButton();
            this.BtnMini = new LayeredSkin.Controls.LayeredButton();
            this.BtnClose = new LayeredSkin.Controls.LayeredButton();
            this.layeredTabControl1 = new LayeredSkin.Controls.LayeredTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ChatListBox = new QQ.Controls.LayeredChatListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.BottonBaseControl = new LayeredSkin.Controls.LayeredBaseControl();
            this.contextMenuStrip1.SuspendLayout();
            this.layeredTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "tab10.png");
            this.imageList1.Images.SetKeyName(1, "tab11.png");
            this.imageList1.Images.SetKeyName(2, "tab12.png");
            this.imageList1.Images.SetKeyName(3, "tab20.png");
            this.imageList1.Images.SetKeyName(4, "tab21.png");
            this.imageList1.Images.SetKeyName(5, "tab22.png");
            this.imageList1.Images.SetKeyName(6, "tab30.png");
            this.imageList1.Images.SetKeyName(7, "tab31.png");
            this.imageList1.Images.SetKeyName(8, "tab32.png");
            // 
            // timer1
            // 
            this.timer1.Interval = 200;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseClick);
            this.notifyIcon1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseMove);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(13, 13);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.在线ToolStripMenuItem,
            this.隐身ToolStripMenuItem,
            this.q我吧ToolStripMenuItem,
            this.离开ToolStripMenuItem,
            this.忙碌ToolStripMenuItem,
            this.请勿打扰ToolStripMenuItem,
            this.离线ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(123, 158);
            // 
            // 在线ToolStripMenuItem
            // 
            this.在线ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("在线ToolStripMenuItem.Image")));
            this.在线ToolStripMenuItem.Name = "在线ToolStripMenuItem";
            this.在线ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.在线ToolStripMenuItem.Tag = "0x0A";
            this.在线ToolStripMenuItem.Text = "在线";
            this.在线ToolStripMenuItem.BackColorChanged += new System.EventHandler(this.StateItemsClick);
            // 
            // 隐身ToolStripMenuItem
            // 
            this.隐身ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("隐身ToolStripMenuItem.Image")));
            this.隐身ToolStripMenuItem.Name = "隐身ToolStripMenuItem";
            this.隐身ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.隐身ToolStripMenuItem.Tag = "0x14";
            this.隐身ToolStripMenuItem.Text = "隐身";
            this.隐身ToolStripMenuItem.BackColorChanged += new System.EventHandler(this.StateItemsClick);
            // 
            // q我吧ToolStripMenuItem
            // 
            this.q我吧ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("q我吧ToolStripMenuItem.Image")));
            this.q我吧ToolStripMenuItem.Name = "q我吧ToolStripMenuItem";
            this.q我吧ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.q我吧ToolStripMenuItem.Tag = "0x3C";
            this.q我吧ToolStripMenuItem.Text = "Q我吧";
            this.q我吧ToolStripMenuItem.BackColorChanged += new System.EventHandler(this.StateItemsClick);
            // 
            // 离开ToolStripMenuItem
            // 
            this.离开ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("离开ToolStripMenuItem.Image")));
            this.离开ToolStripMenuItem.Name = "离开ToolStripMenuItem";
            this.离开ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.离开ToolStripMenuItem.Tag = "0x1E";
            this.离开ToolStripMenuItem.Text = "离开";
            this.离开ToolStripMenuItem.BackColorChanged += new System.EventHandler(this.StateItemsClick);
            // 
            // 忙碌ToolStripMenuItem
            // 
            this.忙碌ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("忙碌ToolStripMenuItem.Image")));
            this.忙碌ToolStripMenuItem.Name = "忙碌ToolStripMenuItem";
            this.忙碌ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.忙碌ToolStripMenuItem.Tag = "0x32";
            this.忙碌ToolStripMenuItem.Text = "忙碌";
            this.忙碌ToolStripMenuItem.BackColorChanged += new System.EventHandler(this.StateItemsClick);
            // 
            // 请勿打扰ToolStripMenuItem
            // 
            this.请勿打扰ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("请勿打扰ToolStripMenuItem.Image")));
            this.请勿打扰ToolStripMenuItem.Name = "请勿打扰ToolStripMenuItem";
            this.请勿打扰ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.请勿打扰ToolStripMenuItem.Tag = "0x46";
            this.请勿打扰ToolStripMenuItem.Text = "请勿打扰";
            this.请勿打扰ToolStripMenuItem.BackColorChanged += new System.EventHandler(this.StateItemsClick);
            // 
            // 离线ToolStripMenuItem
            // 
            this.离线ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("离线ToolStripMenuItem.Image")));
            this.离线ToolStripMenuItem.Name = "离线ToolStripMenuItem";
            this.离线ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.离线ToolStripMenuItem.Tag = "0x28";
            this.离线ToolStripMenuItem.Text = "离线";
            this.离线ToolStripMenuItem.BackColorChanged += new System.EventHandler(this.StateItemsClick);
            // 
            // layeredDragBar3
            // 
            this.layeredDragBar3.AdaptImage = true;
            this.layeredDragBar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredDragBar3.BaseColor = System.Drawing.Color.Wheat;
            this.layeredDragBar3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredDragBar3.Borders.BottomWidth = 1;
            this.layeredDragBar3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredDragBar3.Borders.LeftWidth = 1;
            this.layeredDragBar3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredDragBar3.Borders.RightWidth = 1;
            this.layeredDragBar3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredDragBar3.Borders.TopWidth = 1;
            this.layeredDragBar3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredDragBar3.Canvas")));
            this.layeredDragBar3.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredDragBar3.Dock = System.Windows.Forms.DockStyle.Top;
            this.layeredDragBar3.DragBarPosition = LayeredSkin.Controls.DragBarPositions.Top;
            this.layeredDragBar3.DrawDragBar = true;
            this.layeredDragBar3.ForeColor = System.Drawing.Color.White;
            this.layeredDragBar3.HaloColor = System.Drawing.Color.White;
            this.layeredDragBar3.HaloSize = 5;
            this.layeredDragBar3.HoverImage = null;
            this.layeredDragBar3.IsPureColor = false;
            this.layeredDragBar3.Location = new System.Drawing.Point(5, 4);
            this.layeredDragBar3.Name = "layeredDragBar3";
            this.layeredDragBar3.NormalImage = null;
            this.layeredDragBar3.PressedImage = null;
            this.layeredDragBar3.Radius = 10;
            this.layeredDragBar3.ShowBorder = true;
            this.layeredDragBar3.Size = new System.Drawing.Size(290, 1);
            this.layeredDragBar3.TabIndex = 38;
            this.layeredDragBar3.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredDragBar3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredDragBar3.TextShowMode = LayeredSkin.TextShowModes.None;
            // 
            // layeredDragBar4
            // 
            this.layeredDragBar4.AdaptImage = true;
            this.layeredDragBar4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredDragBar4.BaseColor = System.Drawing.Color.Wheat;
            this.layeredDragBar4.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredDragBar4.Borders.BottomWidth = 1;
            this.layeredDragBar4.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredDragBar4.Borders.LeftWidth = 1;
            this.layeredDragBar4.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredDragBar4.Borders.RightWidth = 1;
            this.layeredDragBar4.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredDragBar4.Borders.TopWidth = 1;
            this.layeredDragBar4.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredDragBar4.Canvas")));
            this.layeredDragBar4.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredDragBar4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.layeredDragBar4.DragBarPosition = LayeredSkin.Controls.DragBarPositions.Bottom;
            this.layeredDragBar4.DrawDragBar = true;
            this.layeredDragBar4.ForeColor = System.Drawing.Color.White;
            this.layeredDragBar4.HaloColor = System.Drawing.Color.White;
            this.layeredDragBar4.HaloSize = 5;
            this.layeredDragBar4.HoverImage = null;
            this.layeredDragBar4.IsPureColor = false;
            this.layeredDragBar4.Location = new System.Drawing.Point(5, 575);
            this.layeredDragBar4.Name = "layeredDragBar4";
            this.layeredDragBar4.NormalImage = null;
            this.layeredDragBar4.PressedImage = null;
            this.layeredDragBar4.Radius = 10;
            this.layeredDragBar4.ShowBorder = true;
            this.layeredDragBar4.Size = new System.Drawing.Size(290, 1);
            this.layeredDragBar4.TabIndex = 39;
            this.layeredDragBar4.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredDragBar4.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredDragBar4.TextShowMode = LayeredSkin.TextShowModes.None;
            // 
            // layeredDragBar1
            // 
            this.layeredDragBar1.AdaptImage = true;
            this.layeredDragBar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredDragBar1.BaseColor = System.Drawing.Color.Wheat;
            this.layeredDragBar1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredDragBar1.Borders.BottomWidth = 1;
            this.layeredDragBar1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredDragBar1.Borders.LeftWidth = 1;
            this.layeredDragBar1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredDragBar1.Borders.RightWidth = 1;
            this.layeredDragBar1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredDragBar1.Borders.TopWidth = 1;
            this.layeredDragBar1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredDragBar1.Canvas")));
            this.layeredDragBar1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredDragBar1.Dock = System.Windows.Forms.DockStyle.Right;
            this.layeredDragBar1.DragBarPosition = LayeredSkin.Controls.DragBarPositions.Right;
            this.layeredDragBar1.DrawDragBar = true;
            this.layeredDragBar1.ForeColor = System.Drawing.Color.White;
            this.layeredDragBar1.HaloColor = System.Drawing.Color.White;
            this.layeredDragBar1.HaloSize = 5;
            this.layeredDragBar1.HoverImage = null;
            this.layeredDragBar1.IsPureColor = false;
            this.layeredDragBar1.Location = new System.Drawing.Point(295, 4);
            this.layeredDragBar1.Name = "layeredDragBar1";
            this.layeredDragBar1.NormalImage = null;
            this.layeredDragBar1.PressedImage = null;
            this.layeredDragBar1.Radius = 10;
            this.layeredDragBar1.ShowBorder = true;
            this.layeredDragBar1.Size = new System.Drawing.Size(1, 572);
            this.layeredDragBar1.TabIndex = 36;
            this.layeredDragBar1.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredDragBar1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredDragBar1.TextShowMode = LayeredSkin.TextShowModes.None;
            // 
            // layeredDragBar2
            // 
            this.layeredDragBar2.AdaptImage = true;
            this.layeredDragBar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredDragBar2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredDragBar2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredDragBar2.Borders.BottomWidth = 1;
            this.layeredDragBar2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredDragBar2.Borders.LeftWidth = 1;
            this.layeredDragBar2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredDragBar2.Borders.RightWidth = 1;
            this.layeredDragBar2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredDragBar2.Borders.TopWidth = 1;
            this.layeredDragBar2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredDragBar2.Canvas")));
            this.layeredDragBar2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredDragBar2.Dock = System.Windows.Forms.DockStyle.Left;
            this.layeredDragBar2.DragBarPosition = LayeredSkin.Controls.DragBarPositions.Left;
            this.layeredDragBar2.DrawDragBar = true;
            this.layeredDragBar2.ForeColor = System.Drawing.Color.White;
            this.layeredDragBar2.HaloColor = System.Drawing.Color.White;
            this.layeredDragBar2.HaloSize = 5;
            this.layeredDragBar2.HoverImage = null;
            this.layeredDragBar2.IsPureColor = false;
            this.layeredDragBar2.Location = new System.Drawing.Point(4, 4);
            this.layeredDragBar2.Name = "layeredDragBar2";
            this.layeredDragBar2.NormalImage = null;
            this.layeredDragBar2.PressedImage = null;
            this.layeredDragBar2.Radius = 10;
            this.layeredDragBar2.ShowBorder = true;
            this.layeredDragBar2.Size = new System.Drawing.Size(1, 572);
            this.layeredDragBar2.TabIndex = 37;
            this.layeredDragBar2.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredDragBar2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredDragBar2.TextShowMode = LayeredSkin.TextShowModes.None;
            // 
            // HeadBaseControl
            // 
            this.HeadBaseControl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.HeadBaseControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.HeadBaseControl.Borders.BottomColor = System.Drawing.Color.Empty;
            this.HeadBaseControl.Borders.BottomWidth = 1;
            this.HeadBaseControl.Borders.LeftColor = System.Drawing.Color.Empty;
            this.HeadBaseControl.Borders.LeftWidth = 1;
            this.HeadBaseControl.Borders.RightColor = System.Drawing.Color.Empty;
            this.HeadBaseControl.Borders.RightWidth = 1;
            this.HeadBaseControl.Borders.TopColor = System.Drawing.Color.Empty;
            this.HeadBaseControl.Borders.TopWidth = 1;
            this.HeadBaseControl.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("HeadBaseControl.Canvas")));
            this.HeadBaseControl.Location = new System.Drawing.Point(4, 47);
            this.HeadBaseControl.Name = "HeadBaseControl";
            this.HeadBaseControl.Size = new System.Drawing.Size(221, 74);
            this.HeadBaseControl.TabIndex = 33;
            // 
            // BaseControlWeather
            // 
            this.BaseControlWeather.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BaseControlWeather.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BaseControlWeather.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BaseControlWeather.Borders.BottomWidth = 1;
            this.BaseControlWeather.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BaseControlWeather.Borders.LeftWidth = 1;
            this.BaseControlWeather.Borders.RightColor = System.Drawing.Color.Empty;
            this.BaseControlWeather.Borders.RightWidth = 1;
            this.BaseControlWeather.Borders.TopColor = System.Drawing.Color.Empty;
            this.BaseControlWeather.Borders.TopWidth = 1;
            this.BaseControlWeather.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BaseControlWeather.Canvas")));
            this.BaseControlWeather.Location = new System.Drawing.Point(230, 47);
            this.BaseControlWeather.Name = "BaseControlWeather";
            this.BaseControlWeather.Size = new System.Drawing.Size(60, 62);
            this.BaseControlWeather.TabIndex = 35;
            this.BaseControlWeather.Text = "layeredBaseControl1";
            this.BaseControlWeather.MouseEnter += new System.EventHandler(this.WeatherMouseEnter);
            this.BaseControlWeather.MouseLeave += new System.EventHandler(this.WeatherMouseLeave);
            // 
            // BtnSearch
            // 
            this.BtnSearch.AdaptImage = true;
            this.BtnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnSearch.BaseColor = System.Drawing.Color.Wheat;
            this.BtnSearch.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnSearch.Borders.BottomWidth = 1;
            this.BtnSearch.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnSearch.Borders.LeftWidth = 1;
            this.BtnSearch.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnSearch.Borders.RightWidth = 1;
            this.BtnSearch.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnSearch.Borders.TopWidth = 1;
            this.BtnSearch.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnSearch.Canvas")));
            this.BtnSearch.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnSearch.HaloColor = System.Drawing.Color.White;
            this.BtnSearch.HaloSize = 5;
            this.BtnSearch.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnSearch.HoverImage")));
            this.BtnSearch.IsPureColor = false;
            this.BtnSearch.Location = new System.Drawing.Point(271, 125);
            this.BtnSearch.Name = "BtnSearch";
            this.BtnSearch.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnSearch.NormalImage")));
            this.BtnSearch.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnSearch.PressedImage")));
            this.BtnSearch.Radius = 10;
            this.BtnSearch.ShowBorder = true;
            this.BtnSearch.Size = new System.Drawing.Size(20, 20);
            this.BtnSearch.TabIndex = 32;
            this.BtnSearch.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnSearch.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnSearch.TextShowMode = LayeredSkin.TextShowModes.Halo;
            // 
            // TxtSearch
            // 
            this.TxtSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TxtSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TxtSearch.Borders.BottomColor = System.Drawing.Color.Silver;
            this.TxtSearch.Borders.BottomWidth = 1;
            this.TxtSearch.Borders.LeftColor = System.Drawing.Color.Silver;
            this.TxtSearch.Borders.LeftWidth = 1;
            this.TxtSearch.Borders.RightColor = System.Drawing.Color.Silver;
            this.TxtSearch.Borders.RightWidth = 1;
            this.TxtSearch.Borders.TopColor = System.Drawing.Color.Silver;
            this.TxtSearch.Borders.TopWidth = 1;
            this.TxtSearch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtSearch.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("TxtSearch.Canvas")));
            this.TxtSearch.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxtSearch.Location = new System.Drawing.Point(5, 122);
            this.TxtSearch.Multiline = true;
            this.TxtSearch.Name = "TxtSearch";
            this.TxtSearch.PasswordChar = '●';
            this.TxtSearch.Size = new System.Drawing.Size(290, 26);
            this.TxtSearch.TabIndex = 31;
            this.TxtSearch.TransparencyKey = System.Drawing.Color.Empty;
            this.TxtSearch.WaterFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxtSearch.WaterText = "搜索：联系人、讨论组、群、企业";
            this.TxtSearch.WaterTextOffset = new System.Drawing.Point(2, 4);
            this.TxtSearch.TextChanged += new System.EventHandler(this.TxtSearch_TextChanged);
            // 
            // layeredButton2
            // 
            this.layeredButton2.AdaptImage = true;
            this.layeredButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.layeredButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.BottomWidth = 1;
            this.layeredButton2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.LeftWidth = 1;
            this.layeredButton2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.RightWidth = 1;
            this.layeredButton2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.TopWidth = 1;
            this.layeredButton2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton2.Canvas")));
            this.layeredButton2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton2.HaloColor = System.Drawing.Color.White;
            this.layeredButton2.HaloSize = 5;
            this.layeredButton2.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.HoverImage")));
            this.layeredButton2.IsPureColor = false;
            this.layeredButton2.Location = new System.Drawing.Point(184, 8);
            this.layeredButton2.Name = "layeredButton2";
            this.layeredButton2.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.NormalImage")));
            this.layeredButton2.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.PressedImage")));
            this.layeredButton2.Radius = 10;
            this.layeredButton2.ShowBorder = true;
            this.layeredButton2.Size = new System.Drawing.Size(20, 20);
            this.layeredButton2.TabIndex = 28;
            this.layeredButton2.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton2.TextShowMode = LayeredSkin.TextShowModes.Halo;
            // 
            // layeredButton1
            // 
            this.layeredButton1.AdaptImage = true;
            this.layeredButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.layeredButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton1.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.BottomWidth = 1;
            this.layeredButton1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.LeftWidth = 1;
            this.layeredButton1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.RightWidth = 1;
            this.layeredButton1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.TopWidth = 1;
            this.layeredButton1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton1.Canvas")));
            this.layeredButton1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton1.HaloColor = System.Drawing.Color.White;
            this.layeredButton1.HaloSize = 5;
            this.layeredButton1.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.HoverImage")));
            this.layeredButton1.IsPureColor = false;
            this.layeredButton1.Location = new System.Drawing.Point(210, 6);
            this.layeredButton1.Name = "layeredButton1";
            this.layeredButton1.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.NormalImage")));
            this.layeredButton1.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.PressedImage")));
            this.layeredButton1.Radius = 10;
            this.layeredButton1.ShowBorder = true;
            this.layeredButton1.Size = new System.Drawing.Size(25, 26);
            this.layeredButton1.TabIndex = 29;
            this.layeredButton1.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton1.TextShowMode = LayeredSkin.TextShowModes.Halo;
            // 
            // BtnMini
            // 
            this.BtnMini.AdaptImage = true;
            this.BtnMini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnMini.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnMini.BaseColor = System.Drawing.Color.Wheat;
            this.BtnMini.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.BottomWidth = 1;
            this.BtnMini.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.LeftWidth = 1;
            this.BtnMini.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.RightWidth = 1;
            this.BtnMini.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.TopWidth = 1;
            this.BtnMini.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnMini.Canvas")));
            this.BtnMini.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnMini.HaloColor = System.Drawing.Color.White;
            this.BtnMini.HaloSize = 5;
            this.BtnMini.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.HoverImage")));
            this.BtnMini.IsPureColor = false;
            this.BtnMini.Location = new System.Drawing.Point(235, 5);
            this.BtnMini.Name = "BtnMini";
            this.BtnMini.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.NormalImage")));
            this.BtnMini.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.PressedImage")));
            this.BtnMini.Radius = 10;
            this.BtnMini.ShowBorder = true;
            this.BtnMini.Size = new System.Drawing.Size(30, 27);
            this.BtnMini.TabIndex = 30;
            this.BtnMini.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnMini.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnMini.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnMini.Click += new System.EventHandler(this.BtnMiniClick);
            // 
            // BtnClose
            // 
            this.BtnClose.AdaptImage = true;
            this.BtnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnClose.BaseColor = System.Drawing.Color.Wheat;
            this.BtnClose.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.BottomWidth = 1;
            this.BtnClose.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.LeftWidth = 1;
            this.BtnClose.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.RightWidth = 1;
            this.BtnClose.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.TopWidth = 1;
            this.BtnClose.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnClose.Canvas")));
            this.BtnClose.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnClose.HaloColor = System.Drawing.Color.White;
            this.BtnClose.HaloSize = 5;
            this.BtnClose.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.HoverImage")));
            this.BtnClose.IsPureColor = false;
            this.BtnClose.Location = new System.Drawing.Point(265, 5);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.NormalImage")));
            this.BtnClose.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.PressedImage")));
            this.BtnClose.Radius = 10;
            this.BtnClose.ShowBorder = true;
            this.BtnClose.Size = new System.Drawing.Size(30, 27);
            this.BtnClose.TabIndex = 27;
            this.BtnClose.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnClose.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnClose.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnClose.Click += new System.EventHandler(this.BtnCloseClick);
            // 
            // layeredTabControl1
            // 
            this.layeredTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.layeredTabControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredTabControl1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredTabControl1.Borders.BottomWidth = 1;
            this.layeredTabControl1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredTabControl1.Borders.LeftWidth = 1;
            this.layeredTabControl1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredTabControl1.Borders.RightWidth = 1;
            this.layeredTabControl1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredTabControl1.Borders.TopWidth = 1;
            this.layeredTabControl1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredTabControl1.Canvas")));
            this.layeredTabControl1.Controls.Add(this.tabPage1);
            this.layeredTabControl1.Controls.Add(this.tabPage2);
            this.layeredTabControl1.Controls.Add(this.tabPage3);
            this.layeredTabControl1.HoverBackColors = new System.Drawing.Color[] {
        System.Drawing.Color.Transparent,
        System.Drawing.Color.Transparent};
            this.layeredTabControl1.ImageList = this.imageList1;
            this.layeredTabControl1.ItemBackgroundImage = null;
            this.layeredTabControl1.ItemBackgroundImageHover = null;
            this.layeredTabControl1.ItemBackgroundImageSelected = null;
            this.layeredTabControl1.ItemSize = new System.Drawing.Size(52, 37);
            this.layeredTabControl1.Location = new System.Drawing.Point(5, 149);
            this.layeredTabControl1.Name = "layeredTabControl1";
            this.layeredTabControl1.NormalBackColors = new System.Drawing.Color[] {
        System.Drawing.Color.Transparent,
        System.Drawing.Color.Transparent};
            this.layeredTabControl1.SelectedBackColors = new System.Drawing.Color[] {
        System.Drawing.Color.Transparent,
        System.Drawing.Color.Transparent};
            this.layeredTabControl1.SelectedIndex = 0;
            this.layeredTabControl1.Size = new System.Drawing.Size(290, 360);
            this.layeredTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.layeredTabControl1.TabIndex = 0;
            this.layeredTabControl1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.layeredTabControl1.SelectedIndexChanged += new System.EventHandler(this.TabControlSelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(233)))), ((int)(((byte)(240)))));
            this.tabPage1.Controls.Add(this.ChatListBox);
            this.tabPage1.ImageIndex = 2;
            this.tabPage1.Location = new System.Drawing.Point(0, 37);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(290, 323);
            this.tabPage1.TabIndex = 0;
            // 
            // ChatListBox
            // 
            this.ChatListBox.AutoFocus = false;
            this.ChatListBox.BackColor = System.Drawing.Color.Transparent;
            this.ChatListBox.Borders.BottomColor = System.Drawing.Color.Empty;
            this.ChatListBox.Borders.BottomWidth = 1;
            this.ChatListBox.Borders.LeftColor = System.Drawing.Color.Empty;
            this.ChatListBox.Borders.LeftWidth = 1;
            this.ChatListBox.Borders.RightColor = System.Drawing.Color.Empty;
            this.ChatListBox.Borders.RightWidth = 1;
            this.ChatListBox.Borders.TopColor = System.Drawing.Color.Empty;
            this.ChatListBox.Borders.TopWidth = 1;
            this.ChatListBox.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("ChatListBox.Canvas")));
            this.ChatListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChatListBox.EnabledMouseWheel = true;
            this.ChatListBox.GroupMouseEnterBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.ChatListBox.GroupMouseLeaveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(233)))), ((int)(((byte)(240)))));
            this.ChatListBox.IsSmallHead = false;
            this.ChatListBox.ItemMoveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(252)))), ((int)(((byte)(240)))), ((int)(((byte)(193)))));
            this.ChatListBox.ItemNomalBackColor = System.Drawing.Color.Transparent;
            this.ChatListBox.ItemSelectBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(240)))), ((int)(((byte)(193)))));
            this.ChatListBox.ItemSize = new System.Drawing.Size(100, 100);
            this.ChatListBox.ListTop = 0;
            this.ChatListBox.Location = new System.Drawing.Point(3, 3);
            this.ChatListBox.Name = "ChatListBox";
            this.ChatListBox.Orientation = LayeredSkin.Controls.ListOrientation.Vertical;
            this.ChatListBox.RollSize = 20;
            this.ChatListBox.ScrollBarBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ChatListBox.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ChatListBox.ScrollBarHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ChatListBox.ScrollBarWidth = 10;
            this.ChatListBox.ShowScrollBar = true;
            this.ChatListBox.Size = new System.Drawing.Size(284, 317);
            this.ChatListBox.SmoothScroll = false;
            this.ChatListBox.TabIndex = 0;
            this.ChatListBox.Text = "layeredChatListBox1";
            this.ChatListBox.Ulmul = false;
            this.ChatListBox.Value = 0D;
            this.ChatListBox.DoubleClickItem += new QQ.Controls.LayeredChatListBox.ChatListEventHandler(this.ChatListBoxDoubleClickItem);
            this.ChatListBox.MouseEnterHead += new QQ.Controls.LayeredChatListBox.ChatHeadEventHandler(this.ChatListBoxMouseEnterHead);
            this.ChatListBox.MouseLeaveHead += new QQ.Controls.LayeredChatListBox.ChatHeadEventHandler(this.ChatListBoxMouseLeaveHead);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(233)))), ((int)(((byte)(240)))));
            this.tabPage2.ImageIndex = 3;
            this.tabPage2.Location = new System.Drawing.Point(0, 37);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(290, 323);
            this.tabPage2.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(233)))), ((int)(((byte)(240)))));
            this.tabPage3.ImageIndex = 6;
            this.tabPage3.Location = new System.Drawing.Point(0, 37);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(290, 323);
            this.tabPage3.TabIndex = 2;
            // 
            // BottonBaseControl
            // 
            this.BottonBaseControl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BottonBaseControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BottonBaseControl.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BottonBaseControl.Borders.BottomWidth = 1;
            this.BottonBaseControl.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BottonBaseControl.Borders.LeftWidth = 1;
            this.BottonBaseControl.Borders.RightColor = System.Drawing.Color.Empty;
            this.BottonBaseControl.Borders.RightWidth = 1;
            this.BottonBaseControl.Borders.TopColor = System.Drawing.Color.Empty;
            this.BottonBaseControl.Borders.TopWidth = 1;
            this.BottonBaseControl.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BottonBaseControl.Canvas")));
            this.BottonBaseControl.Location = new System.Drawing.Point(5, 508);
            this.BottonBaseControl.Name = "BottonBaseControl";
            this.BottonBaseControl.Size = new System.Drawing.Size(290, 67);
            this.BottonBaseControl.TabIndex = 34;
            this.BottonBaseControl.Text = "layeredBaseControl1";
            // 
            // FrmMain
            // 
            this.AnimationType = LayeredSkin.Forms.AnimationTypes.GradualCurtainEffect;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.CaptionHeight = 30;
            this.ClientSize = new System.Drawing.Size(300, 580);
            this.Controls.Add(this.BaseControlWeather);
            this.Controls.Add(this.layeredDragBar3);
            this.Controls.Add(this.layeredDragBar4);
            this.Controls.Add(this.layeredDragBar1);
            this.Controls.Add(this.layeredDragBar2);
            this.Controls.Add(this.HeadBaseControl);
            this.Controls.Add(this.BtnSearch);
            this.Controls.Add(this.TxtSearch);
            this.Controls.Add(this.layeredButton2);
            this.Controls.Add(this.layeredButton1);
            this.Controls.Add(this.BtnMini);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.layeredTabControl1);
            this.Controls.Add(this.BottonBaseControl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IconRectangle = new System.Drawing.Rectangle(10, 10, 35, 14);
            this.MinimumSize = new System.Drawing.Size(300, 580);
            this.Name = "FrmMain";
            this.Padding = new System.Windows.Forms.Padding(4);
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = " ";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.layeredTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private LayeredSkin.Controls.LayeredButton layeredButton2;
        private LayeredSkin.Controls.LayeredButton layeredButton1;
        private LayeredSkin.Controls.LayeredButton BtnMini;
        private LayeredSkin.Controls.LayeredButton BtnClose;
        private LayeredSkin.Controls.LayeredTabControl layeredTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ImageList imageList1;
        private LayeredSkin.Controls.LayeredButton BtnSearch;
        private LayeredSkin.Controls.LayeredTextBox TxtSearch;
        private LayeredSkin.Controls.LayeredBaseControl HeadBaseControl;
        private LayeredSkin.Controls.LayeredBaseControl BottonBaseControl;
        private LayeredSkin.Controls.LayeredBaseControl BaseControlWeather;
        private LayeredSkin.Controls.LayeredDragBar layeredDragBar3;
        private LayeredSkin.Controls.LayeredDragBar layeredDragBar4;
        private LayeredSkin.Controls.LayeredDragBar layeredDragBar1;
        private LayeredSkin.Controls.LayeredDragBar layeredDragBar2;
        private QQ.Controls.LayeredChatListBox ChatListBox;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 在线ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 隐身ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem q我吧ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 离开ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 忙碌ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 请勿打扰ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 离线ToolStripMenuItem;
    }
}