﻿using System;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;
using LayeredSkin.DirectUI;

namespace QQ_LayeredSkin
{
    public partial class FrmSetting : LayeredBaseForm
    {
        private Font _font = new Font("微软雅黑", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
            ((byte)(134)));
        public FrmSetting()
        {
            InitializeComponent();
        }

        private void FrmSetting_Load(object sender, EventArgs e)
        {
            TopBaseControl.BackColor = Color.WhiteSmoke;
            TopBaseControl.Borders.BottomColor = Color.FromArgb(255, 224, 224, 224);
            layeredListBox1.BackColor = Color.WhiteSmoke;
            layeredListBox2.BackColor = Color.White;
            layeredListBox2.ScrollBarBackColor = Color.White;
            AddItems("6", "登陆", Color.White);
            AddItems("4", "主面板", Color.WhiteSmoke);
            AddItems("11", "状态", Color.WhiteSmoke);
            AddItems("11", "会话窗口", Color.WhiteSmoke);
            AddItems("11", "信息展示", Color.WhiteSmoke);
            AddItems("11", "提醒", Color.WhiteSmoke);
            AddItems("11", "热键", Color.WhiteSmoke);

            AddInfoItems(0, true, "开机时自动启动", Color.Transparent);
            AddInfoItems(0, false, "启动QQ时为我自动登录", Color.Transparent);
            AddInfoItems(0, false, "总是打开登录提示", Color.Transparent);
            AddInfoItems(0, false, "登录后自动运行QQ宠物", Color.Transparent);
            AddInfoItems(0, false, "登录后显示拍拍代办事项提示", Color.Transparent);
            AddInfoItems(0, false, "订阅“QQ网购每日精选”,了解最新商品资讯", Color.Transparent);
            AddInfoItems(1, true, "始终保持在其他窗体前端", Color.Transparent);
            AddInfoItems(1, false, "停靠在桌面边缘时自动隐藏", Color.Transparent);
            AddInfoItems(1, false, "在任务栏通知区域显示QQ图标", Color.Transparent);
            AddInfoItems(1, false, "使用动画效果", Color.Transparent);
            AddInfoItems(2, true, "登录状态为：上线", Color.Transparent);
            for (int i = 0; i < 10; i++)
            {
                AddInfoItems(2, false, "3333333333", Color.Transparent);
            }
            AddInfoItems(3, true, "444", Color.Transparent);
            for (int i = 0; i < 10; i++)
            {
                AddInfoItems(3, false, "4444444", Color.Transparent);
            }
            AddInfoItems(4, true, "555", Color.Transparent);
            for (int i = 0; i < 10; i++)
            {
                AddInfoItems(4, false, "5555555555555555", Color.Transparent);
            }
            AddInfoItems(5, true, "666", Color.Transparent);
            for (int i = 0; i < 10; i++)
            {
                AddInfoItems(5, false, "666666666666666", Color.Transparent);
            }
            AddInfoItems(6, true, "777", Color.Transparent);
            for (int i = 0; i < 10; i++)
            {
                AddInfoItems(6, false, "777777777777777", Color.Transparent);
            }
        }

        public void AddItems(string count, string name, Color basecolor)
        {
            DuiBaseControl bc = CreatDuiBaseControl(name);
            bc.Width = layeredListBox1.Width;
            bc.BackColor = basecolor;
            bc.MouseUp += ItemsMouseUp;
            bc.MouseEnter += ItemsMouseEnter;
            bc.MouseLeave += ItemsMouseLeave;
            bc.Height = 35;

            string[] tag = new string[2] { name, count };
            bc.Tag = tag;
            bc.Name = layeredListBox1.Items.Count.ToString();
            layeredListBox1.Items.Add(bc);
        }

        public DuiBaseControl CreatDuiBaseControl(string txtname)
        {
            DuiBaseControl bc = new DuiBaseControl();
            DuiLabel lbDuiLabel = new DuiLabel();
            lbDuiLabel.Text = txtname;
            lbDuiLabel.TextRenderMode = TextRenderingHint.AntiAliasGridFit;
            lbDuiLabel.Size = new Size(layeredListBox1.Width, 35);
            lbDuiLabel.Font = _font;
            lbDuiLabel.TextAlign = ContentAlignment.MiddleLeft;
            lbDuiLabel.Location = new Point(10, 0);
            bc.Controls.Add(lbDuiLabel);
            return bc;
        }
        public void AddInfoItems(int index, bool istitle, string name, Color basecolor)
        {
            DuiBaseControl item = new DuiBaseControl();
            item.Width = layeredListBox2.Width;
            item.Height = 30;

            if (istitle)
            {
                string[] tag = ((string[])layeredListBox1.Items[index].Tag);
                DuiLabel tb = TitleBaseControl(tag[0]);
                tb.Width = layeredListBox2.Width;
                tb.BackColor = basecolor;
                //bc.MouseUp += ItemsMouseUp;
                //bc.MouseEnter += ItemsMouseEnter;
                //bc.MouseLeave += ItemsMouseLeave;
                tb.Height = 30;
                tb.Name = layeredListBox2.Items.Count.ToString();
                item.Controls.Add(tb);
                item.Tag = index;
            }
            else
            {
                item.Tag = "";
            }
            item.Controls.Add(TitleCheckBaseControl(name));
            layeredListBox2.Items.Add(item);
        }
        public DuiLabel TitleBaseControl(string txtname)
        {
            DuiLabel lbDuiLabel = new DuiLabel();
            lbDuiLabel.Text = txtname;
            lbDuiLabel.TextRenderMode = TextRenderingHint.AntiAliasGridFit;
            lbDuiLabel.Size = new Size(60, 30);
            lbDuiLabel.Font = _font;
            lbDuiLabel.TextAlign = ContentAlignment.MiddleLeft;
            lbDuiLabel.Location = new Point(10, 0);
            return lbDuiLabel;
        }
        public DuiCheckBox TitleCheckBaseControl(string txtname)
        {
            DuiCheckBox lbDuiLabel = new DuiCheckBox();
            lbDuiLabel.Text = txtname;
            lbDuiLabel.Size = new Size(layeredListBox2.Width, 30);
            lbDuiLabel.Font = _font;
            lbDuiLabel.Location = new Point(70, 5);
            return lbDuiLabel;
        }
        private int ItemsIndex = 0;
        /// <summary>
        /// 好友项鼠标离开时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseLeave(object sender, EventArgs e)
        {
            if (ItemsIndex != int.Parse(((DuiBaseControl)sender).Name))
            {
                ((DuiBaseControl)sender).BackColor = Color.WhiteSmoke;
            }
        }
        /// <summary>
        /// 好友项鼠标进入控件时显示的背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseEnter(object sender, EventArgs e)
        {
            if (ItemsIndex != int.Parse(((DuiBaseControl)sender).Name))
            {
                ((DuiBaseControl)sender).BackColor = Color.Silver;
            }
        }

        /// <summary>
        /// 好友项点击选中时触发的事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsMouseUp(object sender, MouseEventArgs e)
        {
            if (ItemsIndex != int.Parse(((DuiBaseControl)sender).Name))
            {
                layeredListBox1.Items[ItemsIndex].BackColor = Color.WhiteSmoke;
            }
            ((DuiBaseControl)sender).BackColor = Color.White;
            ItemsIndex = int.Parse(((DuiBaseControl)sender).Name);
            int value = 0;
            for (int i = 0; i < ItemsIndex; i++)
            {
                string[] tag = ((string[])layeredListBox1.Items[i].Tag);
                value = value + int.Parse(tag[1]) * 30;
            }
            layeredListBox2.SetRollValue(-value);
        }

        private void BtnCloseClick(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnMiniClick(object sender, EventArgs e)
        {
            this.WindowState=FormWindowState.Minimized;
        }
    }
}

