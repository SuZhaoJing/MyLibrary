﻿using System;
using System.Drawing;
using System.Windows.Forms;
using LayeredSkin.Controls;
using LayeredSkin.DirectUI;
using QQ.Controls;
using QQ_LayeredSkin.Menu;
using QQ_LayeredSkin.Properties;

namespace QQ_LayeredSkin
{
    public partial class FrmChat : LayeredBaseForm
    {
        public TagFrirendInfo QtagFrirendInfo = null; 
        public FrmChat(TagFrirendInfo tag)
        {
            InitializeComponent();
            QtagFrirendInfo = tag;
            HeadInfomationControl.BackColor = Color.FromArgb(150, Color.GhostWhite);
            HeadInfomationControl.DUIControls.Add(
                        DuiBaseControlClass.AddDuiBaseControl(Resources._1_100, ImageLayout.Stretch,
                            Cursors.Hand,
                            new Size(45, 45), new Point(5, 2)));
            //加载名称
            HeadInfomationControl.DUIControls.Add(DuiBaseControlClass.AddDuiLabel("BinGoo（315567686）", DuiBaseControlClass.Titlefont, new Size(HeadInfomationControl.Width - 45, 25), new Point(53, 2)));
            //加载个性签名
            HeadInfomationControl.DUIControls.Add(DuiBaseControlClass.AddDuiLabel("没有拆不散的情侣，只有不努力的小三... ...", DuiBaseControlClass.Msgfont, new Size(HeadInfomationControl.Width - 48, 15), new Point(53, 30)));
        }

        #region 方法
        /// <summary>
        /// 添加工具栏
        /// </summary>
        public void AddChatTools()
        {
            Bitmap[] chattoolBitmaps = new Bitmap[7]
            {
                ChatResources.chattool1, ChatResources.chattool2,  ChatResources.chattool3,  ChatResources.chattool6,  ChatResources.chattool7,  ChatResources.chattool9,  ChatResources.chattool10
            };
            for (int i = 0; i < chattoolBitmaps.Length; i++)
            {
                AddBottontoolItems(ChatTools,chattoolBitmaps[i], new Size(24, 24), i, 0);
            }

            Bitmap[] chatToptoolBitmaps = new Bitmap[5]
            {
                ChatResources.ChatToptool1, ChatResources.ChatToptool3,  ChatResources.ChatToptool4,  ChatResources.ChatToptool5,  ChatResources.ChatToptool7
            };
            for (int i = 0; i < chatToptoolBitmaps.Length; i++)
            {
                AddBottontoolItems(ChatTopToolControl,chatToptoolBitmaps[i], new Size(35, 35), i, 0);
            }
        }
        /// <summary>
        /// 添加底部Tool按钮（大小16*16）
        /// </summary>
        /// <param name="btmBitmap">tool图标</param>
        /// <param name="index">从左到右第几项</param>
        /// <param name="heightindex">高度行号下标</param>
        public void AddBottontoolItems(LayeredBaseControl toolcontrol,Bitmap btmBitmap, Size size,int index, int heightindex)
        {
            DuiBaseControl BottontoolItems = new DuiBaseControl();
            BottontoolItems.Size = size;
            BottontoolItems.Location = new Point(size.Width * index + 5, heightindex * 30 + 5);
            //vip.BackColor = Color.Transparent;
            BottontoolItems.BackgroundImage = btmBitmap;
            BottontoolItems.Tag = index;
            BottontoolItems.BackgroundImageLayout = ImageLayout.Center;
            BottontoolItems.MouseClick += Tools16MouseClick;
            BottontoolItems.MouseEnter += HightMouseEnter;
            BottontoolItems.MouseLeave += HightMouseLeave;
            toolcontrol.DUIControls.Add(BottontoolItems);
        }
        
        #endregion

        #region 事件

        #region 拖动无边框窗体

        /// <summary>
        /// 窗体鼠标按下事件（移动窗体）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MoveFormMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LayeredSkin.NativeMethods.MouseToMoveControl(this.Handle);
            }
        }
        #endregion

        #region 工具栏单击事件

        private void Tools16MouseClick(object sender, EventArgs e)
        {
            int index = (int)((DuiBaseControl)sender).Tag;

            MessageBox.Show(string.Format("点击了:{0}", index));
        }
        #endregion

        #region DuiBaseControl高亮显示和隐藏事件
        /// <summary>
        /// 鼠标离开控件时不显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HightMouseLeave(object sender, EventArgs e)
        {
            ((DuiBaseControl)sender).Borders.TopColor =
                ((DuiBaseControl)sender).Borders.BottomColor =
                    ((DuiBaseControl)sender).Borders.LeftColor =
                        ((DuiBaseControl)sender).Borders.RightColor = Color.Transparent;
        }
        /// <summary>
        ///  鼠标进入控件时高亮显示边框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HightMouseEnter(object sender, EventArgs e)
        {

            ((DuiBaseControl)sender).Borders.TopColor =
                ((DuiBaseControl)sender).Borders.BottomColor =
                    ((DuiBaseControl)sender).Borders.LeftColor =
                        ((DuiBaseControl)sender).Borders.RightColor = Color.FromArgb(40, Color.Black);
        }
        #endregion 

        private void FrmChat_Load(object sender, EventArgs e)
        {
            ChatTools.BackColor = Color.GhostWhite;
            ChatTopToolControl.BackColor = Color.GhostWhite;
            QQShowControl.BackColor = Color.GhostWhite;
            QQShowControl.BackgroundImage = ChatResources.chatqqshow;
            QQShowControl.BackgroundImageLayout=ImageLayout.Center;
            chatpanel.BackColor = Color.GhostWhite;
            AddChatTools();
        }
        #endregion

        private void layeredButton2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnMini_Click(object sender, EventArgs e)
        {
            this.WindowState=FormWindowState.Minimized;
        }

        private void layeredButton1_Click(object sender, EventArgs e)
        {
            TxtChatRecordMsg.Text += string.Format("{0}\r\n    {1}\r\n", DateTime.Now.ToString("HH:mm:ss"),
                                         TxtSendMsg.Text);
            TxtSendMsg.Text = "";
        }
    }
}
