﻿namespace QQ_LayeredSkin
{
    partial class FrmSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSetting));
            this.BtnMini = new LayeredSkin.Controls.LayeredButton();
            this.BtnClose = new LayeredSkin.Controls.LayeredButton();
            this.layeredTextBox1 = new LayeredSkin.Controls.LayeredTextBox();
            this.TopBaseControl = new LayeredSkin.Controls.LayeredBaseControl();
            this.layeredListBox2 = new LayeredSkin.Controls.LayeredListBox();
            this.layeredListBox1 = new LayeredSkin.Controls.LayeredListBox();
            this.SuspendLayout();
            // 
            // BtnMini
            // 
            this.BtnMini.AdaptImage = true;
            this.BtnMini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnMini.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnMini.BaseColor = System.Drawing.Color.Wheat;
            this.BtnMini.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.BottomWidth = 1;
            this.BtnMini.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.LeftWidth = 1;
            this.BtnMini.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.RightWidth = 1;
            this.BtnMini.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.TopWidth = 1;
            this.BtnMini.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnMini.Canvas")));
            this.BtnMini.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnMini.HaloColor = System.Drawing.Color.White;
            this.BtnMini.HaloSize = 5;
            this.BtnMini.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.HoverImage")));
            this.BtnMini.IsPureColor = false;
            this.BtnMini.Location = new System.Drawing.Point(647, 6);
            this.BtnMini.Name = "BtnMini";
            this.BtnMini.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.NormalImage")));
            this.BtnMini.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.PressedImage")));
            this.BtnMini.Radius = 10;
            this.BtnMini.ShowBorder = true;
            this.BtnMini.Size = new System.Drawing.Size(30, 27);
            this.BtnMini.TabIndex = 40;
            this.BtnMini.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnMini.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnMini.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnMini.Click += new System.EventHandler(this.BtnMiniClick);
            // 
            // BtnClose
            // 
            this.BtnClose.AdaptImage = true;
            this.BtnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnClose.BaseColor = System.Drawing.Color.Wheat;
            this.BtnClose.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.BottomWidth = 1;
            this.BtnClose.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.LeftWidth = 1;
            this.BtnClose.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.RightWidth = 1;
            this.BtnClose.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.TopWidth = 1;
            this.BtnClose.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnClose.Canvas")));
            this.BtnClose.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnClose.HaloColor = System.Drawing.Color.White;
            this.BtnClose.HaloSize = 5;
            this.BtnClose.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.HoverImage")));
            this.BtnClose.IsPureColor = false;
            this.BtnClose.Location = new System.Drawing.Point(677, 6);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.NormalImage")));
            this.BtnClose.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.PressedImage")));
            this.BtnClose.Radius = 10;
            this.BtnClose.ShowBorder = true;
            this.BtnClose.Size = new System.Drawing.Size(30, 27);
            this.BtnClose.TabIndex = 39;
            this.BtnClose.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnClose.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnClose.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnClose.Click += new System.EventHandler(this.BtnCloseClick);
            // 
            // layeredTextBox1
            // 
            this.layeredTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.layeredTextBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredTextBox1.Borders.BottomColor = System.Drawing.Color.DimGray;
            this.layeredTextBox1.Borders.BottomWidth = 1;
            this.layeredTextBox1.Borders.LeftColor = System.Drawing.Color.DarkGray;
            this.layeredTextBox1.Borders.LeftWidth = 1;
            this.layeredTextBox1.Borders.RightColor = System.Drawing.Color.DarkGray;
            this.layeredTextBox1.Borders.RightWidth = 1;
            this.layeredTextBox1.Borders.TopColor = System.Drawing.Color.DarkGray;
            this.layeredTextBox1.Borders.TopWidth = 1;
            this.layeredTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.layeredTextBox1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredTextBox1.Canvas")));
            this.layeredTextBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredTextBox1.Location = new System.Drawing.Point(509, 55);
            this.layeredTextBox1.Name = "layeredTextBox1";
            this.layeredTextBox1.Size = new System.Drawing.Size(173, 22);
            this.layeredTextBox1.TabIndex = 38;
            this.layeredTextBox1.TransparencyKey = System.Drawing.Color.Empty;
            this.layeredTextBox1.WaterFont = new System.Drawing.Font("微软雅黑", 9F);
            this.layeredTextBox1.WaterText = "搜索设置项";
            this.layeredTextBox1.WaterTextOffset = new System.Drawing.Point(4, 2);
            // 
            // TopBaseControl
            // 
            this.TopBaseControl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TopBaseControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TopBaseControl.Borders.BottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TopBaseControl.Borders.BottomWidth = 1;
            this.TopBaseControl.Borders.LeftColor = System.Drawing.Color.Empty;
            this.TopBaseControl.Borders.LeftWidth = 1;
            this.TopBaseControl.Borders.RightColor = System.Drawing.Color.Empty;
            this.TopBaseControl.Borders.RightWidth = 1;
            this.TopBaseControl.Borders.TopColor = System.Drawing.Color.Empty;
            this.TopBaseControl.Borders.TopWidth = 1;
            this.TopBaseControl.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("TopBaseControl.Canvas")));
            this.TopBaseControl.Location = new System.Drawing.Point(6, 43);
            this.TopBaseControl.Name = "TopBaseControl";
            this.TopBaseControl.Size = new System.Drawing.Size(702, 49);
            this.TopBaseControl.TabIndex = 37;
            // 
            // layeredListBox2
            // 
            this.layeredListBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.layeredListBox2.AutoFocus = false;
            this.layeredListBox2.BackColor = System.Drawing.Color.White;
            this.layeredListBox2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredListBox2.Borders.BottomWidth = 1;
            this.layeredListBox2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredListBox2.Borders.LeftWidth = 1;
            this.layeredListBox2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredListBox2.Borders.RightWidth = 1;
            this.layeredListBox2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredListBox2.Borders.TopWidth = 1;
            this.layeredListBox2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredListBox2.Canvas")));
            this.layeredListBox2.EnabledMouseWheel = true;
            this.layeredListBox2.ItemSize = new System.Drawing.Size(100, 100);
            this.layeredListBox2.ListTop = 0;
            this.layeredListBox2.Location = new System.Drawing.Point(160, 92);
            this.layeredListBox2.Name = "layeredListBox2";
            this.layeredListBox2.Orientation = LayeredSkin.Controls.ListOrientation.Vertical;
            this.layeredListBox2.RollSize = 20;
            this.layeredListBox2.ScrollBarBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.layeredListBox2.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.layeredListBox2.ScrollBarHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.layeredListBox2.ScrollBarWidth = 10;
            this.layeredListBox2.ShowScrollBar = true;
            this.layeredListBox2.Size = new System.Drawing.Size(548, 386);
            this.layeredListBox2.SmoothScroll = false;
            this.layeredListBox2.TabIndex = 36;
            this.layeredListBox2.Text = "layeredListBox2";
            this.layeredListBox2.Ulmul = false;
            this.layeredListBox2.Value = 0D;
            // 
            // layeredListBox1
            // 
            this.layeredListBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.layeredListBox1.AutoFocus = false;
            this.layeredListBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.layeredListBox1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredListBox1.Borders.BottomWidth = 1;
            this.layeredListBox1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredListBox1.Borders.LeftWidth = 1;
            this.layeredListBox1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredListBox1.Borders.RightWidth = 1;
            this.layeredListBox1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredListBox1.Borders.TopWidth = 1;
            this.layeredListBox1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredListBox1.Canvas")));
            this.layeredListBox1.EnabledMouseWheel = true;
            this.layeredListBox1.ItemSize = new System.Drawing.Size(152, 35);
            this.layeredListBox1.ListTop = 0;
            this.layeredListBox1.Location = new System.Drawing.Point(6, 92);
            this.layeredListBox1.Name = "layeredListBox1";
            this.layeredListBox1.Orientation = LayeredSkin.Controls.ListOrientation.Vertical;
            this.layeredListBox1.RollSize = 20;
            this.layeredListBox1.ScrollBarBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.layeredListBox1.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.layeredListBox1.ScrollBarHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.layeredListBox1.ScrollBarWidth = 10;
            this.layeredListBox1.ShowScrollBar = true;
            this.layeredListBox1.Size = new System.Drawing.Size(154, 386);
            this.layeredListBox1.SmoothScroll = false;
            this.layeredListBox1.TabIndex = 35;
            this.layeredListBox1.Text = "layeredListBox1";
            this.layeredListBox1.Ulmul = false;
            this.layeredListBox1.Value = 0D;
            // 
            // FrmSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.CaptionColor = System.Drawing.Color.White;
            this.CaptionFont = new System.Drawing.Font("微软雅黑", 9.5F);
            this.CaptionHeight = 26;
            this.CaptionOffset = new System.Drawing.Point(10, 5);
            this.CaptionTextRender = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.ClientSize = new System.Drawing.Size(713, 483);
            this.Controls.Add(this.BtnMini);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.layeredTextBox1);
            this.Controls.Add(this.TopBaseControl);
            this.Controls.Add(this.layeredListBox2);
            this.Controls.Add(this.layeredListBox1);
            this.HaloSize = 1;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IconRectangle = new System.Drawing.Rectangle(10, 10, 16, 16);
            this.Name = "FrmSetting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "系统设置";
            this.Load += new System.EventHandler(this.FrmSetting_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private LayeredSkin.Controls.LayeredTextBox layeredTextBox1;
        private LayeredSkin.Controls.LayeredBaseControl TopBaseControl;
        private LayeredSkin.Controls.LayeredListBox layeredListBox2;
        private LayeredSkin.Controls.LayeredListBox layeredListBox1;
        private LayeredSkin.Controls.LayeredButton BtnMini;
        private LayeredSkin.Controls.LayeredButton BtnClose;
    }
}