﻿namespace QQ_LayeredSkin
{
    partial class FrmLogin
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLogin));
            LayeredSkin.DirectUI.DuiBaseControl duiBaseControl1 = new LayeredSkin.DirectUI.DuiBaseControl();
            LayeredSkin.DirectUI.DuiLabel duiLabel1 = new LayeredSkin.DirectUI.DuiLabel();
            System.Drawing.StringFormat stringFormat1 = new System.Drawing.StringFormat();
            LayeredSkin.DirectUI.DuiCheckBox duiCheckBox1 = new LayeredSkin.DirectUI.DuiCheckBox();
            LayeredSkin.DirectUI.DuiCheckBox duiCheckBox2 = new LayeredSkin.DirectUI.DuiCheckBox();
            this.离线ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.忙碌ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.离开ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.q我吧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.隐身ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.在线ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.请勿打扰ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.layeredButton7 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton6 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton1 = new LayeredSkin.Controls.LayeredButton();
            this.TxtPwd = new LayeredSkin.Controls.LayeredTextBox();
            this.TxtUsername = new LayeredSkin.Controls.LayeredTextBox();
            this.layeredButton4 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton3 = new LayeredSkin.Controls.LayeredButton();
            this.HeadImg = new LayeredSkin.Controls.LayeredBaseControl();
            this.BtnLogin = new LayeredSkin.Controls.LayeredButton();
            this.BtnSet = new LayeredSkin.Controls.LayeredButton();
            this.BtnMini = new LayeredSkin.Controls.LayeredButton();
            this.BtnClose = new LayeredSkin.Controls.LayeredButton();
            this.lblogininfo = new LayeredSkin.Controls.LayeredLabel();
            this.layeredPanel1 = new LayeredSkin.Controls.LayeredPanel();
            this.layeredPanel3 = new LayeredSkin.Controls.LayeredPanel();
            this.layeredBaseControl1 = new LayeredSkin.Controls.LayeredBaseControl();
            this.layeredBaseControl2 = new LayeredSkin.Controls.LayeredBaseControl();
            this.layeredButton2 = new LayeredSkin.Controls.LayeredButton();
            this.contextMenuStrip1.SuspendLayout();
            this.layeredPanel1.SuspendLayout();
            this.layeredPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // 离线ToolStripMenuItem
            // 
            this.离线ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("离线ToolStripMenuItem.Image")));
            this.离线ToolStripMenuItem.Name = "离线ToolStripMenuItem";
            this.离线ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.离线ToolStripMenuItem.Tag = "0x28";
            this.离线ToolStripMenuItem.Text = "离线";
            // 
            // 忙碌ToolStripMenuItem
            // 
            this.忙碌ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("忙碌ToolStripMenuItem.Image")));
            this.忙碌ToolStripMenuItem.Name = "忙碌ToolStripMenuItem";
            this.忙碌ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.忙碌ToolStripMenuItem.Tag = "0x32";
            this.忙碌ToolStripMenuItem.Text = "忙碌";
            // 
            // 离开ToolStripMenuItem
            // 
            this.离开ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("离开ToolStripMenuItem.Image")));
            this.离开ToolStripMenuItem.Name = "离开ToolStripMenuItem";
            this.离开ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.离开ToolStripMenuItem.Tag = "0x1E";
            this.离开ToolStripMenuItem.Text = "离开";
            // 
            // q我吧ToolStripMenuItem
            // 
            this.q我吧ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("q我吧ToolStripMenuItem.Image")));
            this.q我吧ToolStripMenuItem.Name = "q我吧ToolStripMenuItem";
            this.q我吧ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.q我吧ToolStripMenuItem.Tag = "0x3C";
            this.q我吧ToolStripMenuItem.Text = "Q我吧";
            // 
            // 隐身ToolStripMenuItem
            // 
            this.隐身ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("隐身ToolStripMenuItem.Image")));
            this.隐身ToolStripMenuItem.Name = "隐身ToolStripMenuItem";
            this.隐身ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.隐身ToolStripMenuItem.Tag = "0x14";
            this.隐身ToolStripMenuItem.Text = "隐身";
            // 
            // 在线ToolStripMenuItem
            // 
            this.在线ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("在线ToolStripMenuItem.Image")));
            this.在线ToolStripMenuItem.Name = "在线ToolStripMenuItem";
            this.在线ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.在线ToolStripMenuItem.Tag = "0x0A";
            this.在线ToolStripMenuItem.Text = "在线";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(13, 13);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.在线ToolStripMenuItem,
            this.隐身ToolStripMenuItem,
            this.q我吧ToolStripMenuItem,
            this.离开ToolStripMenuItem,
            this.忙碌ToolStripMenuItem,
            this.请勿打扰ToolStripMenuItem,
            this.离线ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(123, 158);
            // 
            // 请勿打扰ToolStripMenuItem
            // 
            this.请勿打扰ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("请勿打扰ToolStripMenuItem.Image")));
            this.请勿打扰ToolStripMenuItem.Name = "请勿打扰ToolStripMenuItem";
            this.请勿打扰ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.请勿打扰ToolStripMenuItem.Tag = "0x46";
            this.请勿打扰ToolStripMenuItem.Text = "请勿打扰";
            // 
            // layeredButton7
            // 
            this.layeredButton7.AdaptImage = true;
            this.layeredButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton7.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton7.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton7.Borders.BottomWidth = 1;
            this.layeredButton7.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton7.Borders.LeftWidth = 1;
            this.layeredButton7.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton7.Borders.RightWidth = 1;
            this.layeredButton7.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton7.Borders.TopWidth = 1;
            this.layeredButton7.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton7.Canvas")));
            this.layeredButton7.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton7.HaloColor = System.Drawing.Color.White;
            this.layeredButton7.HaloSize = 5;
            this.layeredButton7.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton7.HoverImage")));
            this.layeredButton7.IsPureColor = false;
            this.layeredButton7.Location = new System.Drawing.Point(12, 306);
            this.layeredButton7.Name = "layeredButton7";
            this.layeredButton7.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton7.NormalImage")));
            this.layeredButton7.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton7.PressedImage")));
            this.layeredButton7.Radius = 10;
            this.layeredButton7.ShowBorder = true;
            this.layeredButton7.Size = new System.Drawing.Size(24, 24);
            this.layeredButton7.TabIndex = 29;
            this.layeredButton7.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton7.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton7.TextShowMode = LayeredSkin.TextShowModes.Halo;
            // 
            // layeredButton6
            // 
            this.layeredButton6.AdaptImage = true;
            this.layeredButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton6.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton6.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton6.Borders.BottomWidth = 1;
            this.layeredButton6.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton6.Borders.LeftWidth = 1;
            this.layeredButton6.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton6.Borders.RightWidth = 1;
            this.layeredButton6.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton6.Borders.TopWidth = 1;
            this.layeredButton6.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton6.Canvas")));
            this.layeredButton6.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton6.HaloColor = System.Drawing.Color.White;
            this.layeredButton6.HaloSize = 5;
            this.layeredButton6.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton6.HoverImage")));
            this.layeredButton6.IsPureColor = false;
            this.layeredButton6.Location = new System.Drawing.Point(406, 306);
            this.layeredButton6.Name = "layeredButton6";
            this.layeredButton6.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton6.NormalImage")));
            this.layeredButton6.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton6.PressedImage")));
            this.layeredButton6.Radius = 10;
            this.layeredButton6.ShowBorder = true;
            this.layeredButton6.Size = new System.Drawing.Size(24, 24);
            this.layeredButton6.TabIndex = 30;
            this.layeredButton6.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton6.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton6.TextShowMode = LayeredSkin.TextShowModes.Halo;
            // 
            // layeredButton1
            // 
            this.layeredButton1.AdaptImage = true;
            this.layeredButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton1.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.BottomWidth = 1;
            this.layeredButton1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.LeftWidth = 1;
            this.layeredButton1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.RightWidth = 1;
            this.layeredButton1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.TopWidth = 1;
            this.layeredButton1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton1.Canvas")));
            this.layeredButton1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton1.HaloColor = System.Drawing.Color.White;
            this.layeredButton1.HaloSize = 5;
            this.layeredButton1.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.HoverImage")));
            this.layeredButton1.IsPureColor = false;
            this.layeredButton1.Location = new System.Drawing.Point(181, 39);
            this.layeredButton1.Name = "layeredButton1";
            this.layeredButton1.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.NormalImage")));
            this.layeredButton1.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.PressedImage")));
            this.layeredButton1.Radius = 10;
            this.layeredButton1.ShowBorder = true;
            this.layeredButton1.Size = new System.Drawing.Size(15, 16);
            this.layeredButton1.TabIndex = 29;
            this.layeredButton1.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton1.TextShowMode = LayeredSkin.TextShowModes.Halo;
            // 
            // TxtPwd
            // 
            this.TxtPwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TxtPwd.Borders.BottomColor = System.Drawing.Color.Empty;
            this.TxtPwd.Borders.BottomWidth = 1;
            this.TxtPwd.Borders.LeftColor = System.Drawing.Color.Empty;
            this.TxtPwd.Borders.LeftWidth = 1;
            this.TxtPwd.Borders.RightColor = System.Drawing.Color.Empty;
            this.TxtPwd.Borders.RightWidth = 1;
            this.TxtPwd.Borders.TopColor = System.Drawing.Color.Empty;
            this.TxtPwd.Borders.TopWidth = 1;
            this.TxtPwd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtPwd.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("TxtPwd.Canvas")));
            this.TxtPwd.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxtPwd.Location = new System.Drawing.Point(8, 33);
            this.TxtPwd.Multiline = true;
            this.TxtPwd.Name = "TxtPwd";
            this.TxtPwd.PasswordChar = '●';
            this.TxtPwd.Size = new System.Drawing.Size(194, 30);
            this.TxtPwd.TabIndex = 26;
            this.TxtPwd.TransparencyKey = System.Drawing.Color.White;
            this.TxtPwd.WaterFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxtPwd.WaterText = "密码";
            this.TxtPwd.WaterTextOffset = new System.Drawing.Point(3, 5);
            this.TxtPwd.MouseEnter += new System.EventHandler(this.TxtPwd_MouseEnter);
            this.TxtPwd.MouseLeave += new System.EventHandler(this.TxtPwd_MouseLeave);
            // 
            // TxtUsername
            // 
            this.TxtUsername.BackColor = System.Drawing.Color.White;
            this.TxtUsername.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.TxtUsername.Borders.BottomColor = System.Drawing.Color.Empty;
            this.TxtUsername.Borders.BottomWidth = 1;
            this.TxtUsername.Borders.LeftColor = System.Drawing.Color.Empty;
            this.TxtUsername.Borders.LeftWidth = 1;
            this.TxtUsername.Borders.RightColor = System.Drawing.Color.Empty;
            this.TxtUsername.Borders.RightWidth = 1;
            this.TxtUsername.Borders.TopColor = System.Drawing.Color.Empty;
            this.TxtUsername.Borders.TopWidth = 1;
            this.TxtUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtUsername.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("TxtUsername.Canvas")));
            this.TxtUsername.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.TxtUsername.Location = new System.Drawing.Point(8, 3);
            this.TxtUsername.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this.TxtUsername.Multiline = true;
            this.TxtUsername.Name = "TxtUsername";
            this.TxtUsername.Size = new System.Drawing.Size(194, 30);
            this.TxtUsername.TabIndex = 27;
            this.TxtUsername.TransparencyKey = System.Drawing.Color.White;
            this.TxtUsername.WaterFont = new System.Drawing.Font("微软雅黑", 9F);
            this.TxtUsername.WaterText = "QQ账号/手机号/邮箱";
            this.TxtUsername.WaterTextOffset = new System.Drawing.Point(3, 5);
            this.TxtUsername.MouseEnter += new System.EventHandler(this.TxtUsername_MouseEnter);
            this.TxtUsername.MouseLeave += new System.EventHandler(this.TxtUsername_MouseLeave);
            // 
            // layeredButton4
            // 
            this.layeredButton4.AdaptImage = true;
            this.layeredButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton4.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton4.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton4.Borders.BottomWidth = 1;
            this.layeredButton4.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton4.Borders.LeftWidth = 1;
            this.layeredButton4.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton4.Borders.RightWidth = 1;
            this.layeredButton4.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton4.Borders.TopWidth = 1;
            this.layeredButton4.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton4.Canvas")));
            this.layeredButton4.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton4.HaloColor = System.Drawing.Color.White;
            this.layeredButton4.HaloSize = 5;
            this.layeredButton4.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton4.HoverImage")));
            this.layeredButton4.IsPureColor = false;
            this.layeredButton4.Location = new System.Drawing.Point(222, 49);
            this.layeredButton4.Name = "layeredButton4";
            this.layeredButton4.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton4.NormalImage")));
            this.layeredButton4.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton4.PressedImage")));
            this.layeredButton4.Radius = 10;
            this.layeredButton4.ShowBorder = true;
            this.layeredButton4.Size = new System.Drawing.Size(48, 11);
            this.layeredButton4.TabIndex = 23;
            this.layeredButton4.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton4.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton4.TextShowMode = LayeredSkin.TextShowModes.Halo;
            // 
            // layeredButton3
            // 
            this.layeredButton3.AdaptImage = true;
            this.layeredButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton3.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.BottomWidth = 1;
            this.layeredButton3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.LeftWidth = 1;
            this.layeredButton3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.RightWidth = 1;
            this.layeredButton3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.TopWidth = 1;
            this.layeredButton3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton3.Canvas")));
            this.layeredButton3.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton3.HaloColor = System.Drawing.Color.White;
            this.layeredButton3.HaloSize = 5;
            this.layeredButton3.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton3.HoverImage")));
            this.layeredButton3.IsPureColor = false;
            this.layeredButton3.Location = new System.Drawing.Point(222, 12);
            this.layeredButton3.Name = "layeredButton3";
            this.layeredButton3.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton3.NormalImage")));
            this.layeredButton3.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton3.PressedImage")));
            this.layeredButton3.Radius = 10;
            this.layeredButton3.ShowBorder = true;
            this.layeredButton3.Size = new System.Drawing.Size(48, 11);
            this.layeredButton3.TabIndex = 23;
            this.layeredButton3.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton3.TextShowMode = LayeredSkin.TextShowModes.Halo;
            // 
            // HeadImg
            // 
            this.HeadImg.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("HeadImg.BackgroundImage")));
            this.HeadImg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.HeadImg.Borders.BottomColor = System.Drawing.Color.Empty;
            this.HeadImg.Borders.BottomWidth = 1;
            this.HeadImg.Borders.LeftColor = System.Drawing.Color.Empty;
            this.HeadImg.Borders.LeftWidth = 1;
            this.HeadImg.Borders.RightColor = System.Drawing.Color.Empty;
            this.HeadImg.Borders.RightWidth = 1;
            this.HeadImg.Borders.TopColor = System.Drawing.Color.Empty;
            this.HeadImg.Borders.TopWidth = 1;
            this.HeadImg.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("HeadImg.Canvas")));
            this.HeadImg.Location = new System.Drawing.Point(43, 188);
            this.HeadImg.Name = "HeadImg";
            this.HeadImg.Size = new System.Drawing.Size(80, 80);
            this.HeadImg.TabIndex = 33;
            this.HeadImg.Text = "layeredBaseControl3";
            // 
            // BtnLogin
            // 
            this.BtnLogin.AdaptImage = true;
            this.BtnLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnLogin.BaseColor = System.Drawing.Color.Wheat;
            this.BtnLogin.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnLogin.Borders.BottomWidth = 1;
            this.BtnLogin.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnLogin.Borders.LeftWidth = 1;
            this.BtnLogin.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnLogin.Borders.RightWidth = 1;
            this.BtnLogin.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnLogin.Borders.TopWidth = 1;
            this.BtnLogin.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnLogin.Canvas")));
            this.BtnLogin.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            duiBaseControl1.AutoSize = false;
            duiBaseControl1.BackColor = System.Drawing.Color.Empty;
            duiBaseControl1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("duiBaseControl1.BackgroundImage")));
            duiBaseControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            duiBaseControl1.BackgroundRender = null;
            duiBaseControl1.BitmapCache = false;
            duiBaseControl1.BorderPath = null;
            duiBaseControl1.BorderRender = null;
            duiBaseControl1.Borders.BottomColor = System.Drawing.Color.Empty;
            duiBaseControl1.Borders.BottomWidth = 1;
            duiBaseControl1.Borders.LeftColor = System.Drawing.Color.Empty;
            duiBaseControl1.Borders.LeftWidth = 1;
            duiBaseControl1.Borders.RightColor = System.Drawing.Color.Empty;
            duiBaseControl1.Borders.RightWidth = 1;
            duiBaseControl1.Borders.TopColor = System.Drawing.Color.Empty;
            duiBaseControl1.Borders.TopWidth = 1;
            duiBaseControl1.ClientRectangle = new System.Drawing.Rectangle(45, 9, 100, 100);
            duiBaseControl1.CurrentCursor = System.Windows.Forms.Cursors.Default;
            duiBaseControl1.Cursor = System.Windows.Forms.Cursors.Default;
            duiBaseControl1.Dock = System.Windows.Forms.DockStyle.None;
            duiBaseControl1.Enabled = true;
            duiBaseControl1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            duiBaseControl1.ForeColor = System.Drawing.Color.White;
            duiBaseControl1.Height = 100;
            duiBaseControl1.IsMoveParentPaint = true;
            duiBaseControl1.Left = 45;
            duiBaseControl1.Location = new System.Drawing.Point(45, 9);
            duiBaseControl1.Margin = new System.Windows.Forms.Padding(0);
            duiBaseControl1.Name = null;
            duiBaseControl1.ParentInvalidate = true;
            duiBaseControl1.ShowBorder = true;
            duiBaseControl1.Size = new System.Drawing.Size(100, 100);
            duiBaseControl1.Tag = null;
            duiBaseControl1.Top = 9;
            duiBaseControl1.Visible = true;
            duiBaseControl1.Width = 100;
            duiLabel1.AutoSize = false;
            duiLabel1.BackColor = System.Drawing.Color.Empty;
            duiLabel1.BackgroundImage = null;
            duiLabel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            duiLabel1.BackgroundRender = null;
            duiLabel1.BitmapCache = false;
            duiLabel1.BorderPath = null;
            duiLabel1.BorderRender = null;
            duiLabel1.Borders.BottomColor = System.Drawing.Color.Empty;
            duiLabel1.Borders.BottomWidth = 1;
            duiLabel1.Borders.LeftColor = System.Drawing.Color.Empty;
            duiLabel1.Borders.LeftWidth = 1;
            duiLabel1.Borders.RightColor = System.Drawing.Color.Empty;
            duiLabel1.Borders.RightWidth = 1;
            duiLabel1.Borders.TopColor = System.Drawing.Color.Empty;
            duiLabel1.Borders.TopWidth = 1;
            duiLabel1.ClientRectangle = new System.Drawing.Rectangle(65, 6, 100, 100);
            duiLabel1.CurrentCursor = System.Windows.Forms.Cursors.Default;
            duiLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            duiLabel1.Dock = System.Windows.Forms.DockStyle.None;
            duiLabel1.Enabled = true;
            duiLabel1.Font = new System.Drawing.Font("微软雅黑", 9F);
            duiLabel1.ForeColor = System.Drawing.Color.White;
            duiLabel1.Height = 100;
            duiLabel1.IsMoveParentPaint = true;
            duiLabel1.Left = 65;
            duiLabel1.Location = new System.Drawing.Point(65, 6);
            duiLabel1.Margin = new System.Windows.Forms.Padding(0);
            duiLabel1.Name = null;
            duiLabel1.ParentInvalidate = true;
            duiLabel1.ShowBorder = true;
            duiLabel1.Size = new System.Drawing.Size(100, 100);
            stringFormat1.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat1.LineAlignment = System.Drawing.StringAlignment.Near;
            stringFormat1.Trimming = System.Drawing.StringTrimming.Character;
            duiLabel1.StringFormat = stringFormat1;
            duiLabel1.Tag = null;
            duiLabel1.Text = "安 全 登 录";
            duiLabel1.TextPadding = 0;
            duiLabel1.TextRenderMode = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            duiLabel1.Top = 6;
            duiLabel1.Visible = true;
            duiLabel1.Width = 100;
            this.BtnLogin.DUIControls.AddRange(new LayeredSkin.DirectUI.DuiBaseControl[] {
            duiBaseControl1,
            duiLabel1});
            this.BtnLogin.HaloColor = System.Drawing.Color.White;
            this.BtnLogin.HaloSize = 5;
            this.BtnLogin.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnLogin.HoverImage")));
            this.BtnLogin.IsPureColor = false;
            this.BtnLogin.Location = new System.Drawing.Point(136, 295);
            this.BtnLogin.Name = "BtnLogin";
            this.BtnLogin.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnLogin.NormalImage")));
            this.BtnLogin.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnLogin.PressedImage")));
            this.BtnLogin.Radius = 10;
            this.BtnLogin.ShowBorder = true;
            this.BtnLogin.Size = new System.Drawing.Size(194, 30);
            this.BtnLogin.TabIndex = 31;
            this.BtnLogin.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnLogin.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnLogin.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnLogin.Click += new System.EventHandler(this.BtnLoginClick);
            // 
            // BtnSet
            // 
            this.BtnSet.AdaptImage = true;
            this.BtnSet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnSet.BaseColor = System.Drawing.Color.Wheat;
            this.BtnSet.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnSet.Borders.BottomWidth = 1;
            this.BtnSet.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnSet.Borders.LeftWidth = 1;
            this.BtnSet.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnSet.Borders.RightWidth = 1;
            this.BtnSet.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnSet.Borders.TopWidth = 1;
            this.BtnSet.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnSet.Canvas")));
            this.BtnSet.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnSet.HaloColor = System.Drawing.Color.White;
            this.BtnSet.HaloSize = 5;
            this.BtnSet.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnSet.HoverImage")));
            this.BtnSet.IsPureColor = false;
            this.BtnSet.Location = new System.Drawing.Point(342, 0);
            this.BtnSet.Name = "BtnSet";
            this.BtnSet.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnSet.NormalImage")));
            this.BtnSet.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnSet.PressedImage")));
            this.BtnSet.Radius = 10;
            this.BtnSet.ShowBorder = true;
            this.BtnSet.Size = new System.Drawing.Size(30, 27);
            this.BtnSet.TabIndex = 8;
            this.BtnSet.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnSet.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnSet.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnSet.Click += new System.EventHandler(this.BtnSetClick);
            // 
            // BtnMini
            // 
            this.BtnMini.AdaptImage = true;
            this.BtnMini.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnMini.BaseColor = System.Drawing.Color.Wheat;
            this.BtnMini.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.BottomWidth = 1;
            this.BtnMini.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.LeftWidth = 1;
            this.BtnMini.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.RightWidth = 1;
            this.BtnMini.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnMini.Borders.TopWidth = 1;
            this.BtnMini.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnMini.Canvas")));
            this.BtnMini.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnMini.HaloColor = System.Drawing.Color.White;
            this.BtnMini.HaloSize = 5;
            this.BtnMini.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.HoverImage")));
            this.BtnMini.IsPureColor = false;
            this.BtnMini.Location = new System.Drawing.Point(372, 0);
            this.BtnMini.Name = "BtnMini";
            this.BtnMini.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.NormalImage")));
            this.BtnMini.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnMini.PressedImage")));
            this.BtnMini.Radius = 10;
            this.BtnMini.ShowBorder = true;
            this.BtnMini.Size = new System.Drawing.Size(30, 27);
            this.BtnMini.TabIndex = 7;
            this.BtnMini.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnMini.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnMini.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnMini.Click += new System.EventHandler(this.BtnMiniClick);
            // 
            // BtnClose
            // 
            this.BtnClose.AdaptImage = true;
            this.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnClose.BaseColor = System.Drawing.Color.Wheat;
            this.BtnClose.Borders.BottomColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.BottomWidth = 1;
            this.BtnClose.Borders.LeftColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.LeftWidth = 1;
            this.BtnClose.Borders.RightColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.RightWidth = 1;
            this.BtnClose.Borders.TopColor = System.Drawing.Color.Empty;
            this.BtnClose.Borders.TopWidth = 1;
            this.BtnClose.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("BtnClose.Canvas")));
            this.BtnClose.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.BtnClose.HaloColor = System.Drawing.Color.White;
            this.BtnClose.HaloSize = 5;
            this.BtnClose.HoverImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.HoverImage")));
            this.BtnClose.IsPureColor = false;
            this.BtnClose.Location = new System.Drawing.Point(402, 0);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.NormalImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.NormalImage")));
            this.BtnClose.PressedImage = ((System.Drawing.Image)(resources.GetObject("BtnClose.PressedImage")));
            this.BtnClose.Radius = 10;
            this.BtnClose.ShowBorder = true;
            this.BtnClose.Size = new System.Drawing.Size(30, 27);
            this.BtnClose.TabIndex = 6;
            this.BtnClose.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.BtnClose.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.BtnClose.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.BtnClose.Click += new System.EventHandler(this.BtnCloseClick);
            // 
            // lblogininfo
            // 
            this.lblogininfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.lblogininfo.Borders.BottomColor = System.Drawing.Color.Empty;
            this.lblogininfo.Borders.BottomWidth = 1;
            this.lblogininfo.Borders.LeftColor = System.Drawing.Color.Empty;
            this.lblogininfo.Borders.LeftWidth = 1;
            this.lblogininfo.Borders.RightColor = System.Drawing.Color.Empty;
            this.lblogininfo.Borders.RightWidth = 1;
            this.lblogininfo.Borders.TopColor = System.Drawing.Color.Empty;
            this.lblogininfo.Borders.TopWidth = 1;
            this.lblogininfo.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("lblogininfo.Canvas")));
            this.lblogininfo.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblogininfo.HaloSize = 5;
            this.lblogininfo.Location = new System.Drawing.Point(8, 274);
            this.lblogininfo.Name = "lblogininfo";
            this.lblogininfo.Size = new System.Drawing.Size(422, 17);
            this.lblogininfo.TabIndex = 34;
            this.lblogininfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblogininfo.TextRenderMode = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            // 
            // layeredPanel1
            // 
            this.layeredPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("layeredPanel1.BackgroundImage")));
            this.layeredPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.layeredPanel1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredPanel1.Borders.BottomWidth = 1;
            this.layeredPanel1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredPanel1.Borders.LeftWidth = 1;
            this.layeredPanel1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredPanel1.Borders.RightWidth = 1;
            this.layeredPanel1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredPanel1.Borders.TopWidth = 1;
            this.layeredPanel1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredPanel1.Canvas")));
            this.layeredPanel1.Controls.Add(this.BtnSet);
            this.layeredPanel1.Controls.Add(this.BtnMini);
            this.layeredPanel1.Controls.Add(this.BtnClose);
            this.layeredPanel1.Location = new System.Drawing.Point(5, 5);
            this.layeredPanel1.Name = "layeredPanel1";
            this.layeredPanel1.Size = new System.Drawing.Size(432, 177);
            this.layeredPanel1.TabIndex = 28;
            this.layeredPanel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MoveFormMouseDown);
            // 
            // layeredPanel3
            // 
            this.layeredPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredPanel3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredPanel3.Borders.BottomWidth = 1;
            this.layeredPanel3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredPanel3.Borders.LeftWidth = 1;
            this.layeredPanel3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredPanel3.Borders.RightWidth = 1;
            this.layeredPanel3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredPanel3.Borders.TopWidth = 1;
            this.layeredPanel3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredPanel3.Canvas")));
            this.layeredPanel3.Controls.Add(this.layeredBaseControl1);
            this.layeredPanel3.Controls.Add(this.layeredBaseControl2);
            this.layeredPanel3.Controls.Add(this.layeredButton2);
            this.layeredPanel3.Controls.Add(this.layeredButton1);
            this.layeredPanel3.Controls.Add(this.TxtPwd);
            this.layeredPanel3.Controls.Add(this.TxtUsername);
            this.layeredPanel3.Controls.Add(this.layeredButton4);
            this.layeredPanel3.Controls.Add(this.layeredButton3);
            this.layeredPanel3.Location = new System.Drawing.Point(127, 187);
            this.layeredPanel3.Name = "layeredPanel3";
            this.layeredPanel3.Size = new System.Drawing.Size(272, 88);
            this.layeredPanel3.TabIndex = 32;
            // 
            // layeredBaseControl1
            // 
            this.layeredBaseControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredBaseControl1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredBaseControl1.Borders.BottomWidth = 1;
            this.layeredBaseControl1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredBaseControl1.Borders.LeftWidth = 1;
            this.layeredBaseControl1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredBaseControl1.Borders.RightWidth = 1;
            this.layeredBaseControl1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredBaseControl1.Borders.TopWidth = 1;
            this.layeredBaseControl1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredBaseControl1.Canvas")));
            duiCheckBox1.AutoCheck = true;
            duiCheckBox1.AutoSize = true;
            duiCheckBox1.BackColor = System.Drawing.Color.Empty;
            duiCheckBox1.BackgroundImage = null;
            duiCheckBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            duiCheckBox1.BackgroundRender = null;
            duiCheckBox1.BitmapCache = false;
            duiCheckBox1.BorderPath = null;
            duiCheckBox1.BorderRender = null;
            duiCheckBox1.Borders.BottomColor = System.Drawing.Color.Empty;
            duiCheckBox1.Borders.BottomWidth = 1;
            duiCheckBox1.Borders.LeftColor = System.Drawing.Color.Empty;
            duiCheckBox1.Borders.LeftWidth = 1;
            duiCheckBox1.Borders.RightColor = System.Drawing.Color.Empty;
            duiCheckBox1.Borders.RightWidth = 1;
            duiCheckBox1.Borders.TopColor = System.Drawing.Color.Empty;
            duiCheckBox1.Borders.TopWidth = 1;
            duiCheckBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft;
            duiCheckBox1.Checked = false;
            duiCheckBox1.CheckedHover = ((System.Drawing.Image)(resources.GetObject("duiCheckBox1.CheckedHover")));
            duiCheckBox1.CheckedNormal = ((System.Drawing.Image)(resources.GetObject("duiCheckBox1.CheckedNormal")));
            duiCheckBox1.CheckedPressed = ((System.Drawing.Image)(resources.GetObject("duiCheckBox1.CheckedPressed")));
            duiCheckBox1.CheckFlagColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(151)))), ((int)(((byte)(2)))));
            duiCheckBox1.CheckFlagColorDisabled = System.Drawing.Color.Gray;
            duiCheckBox1.CheckRectBackColorDisabled = System.Drawing.Color.Silver;
            duiCheckBox1.CheckRectBackColorHighLight = System.Drawing.Color.White;
            duiCheckBox1.CheckRectBackColorNormal = System.Drawing.Color.White;
            duiCheckBox1.CheckRectBackColorPressed = System.Drawing.Color.White;
            duiCheckBox1.CheckRectColor = System.Drawing.Color.DodgerBlue;
            duiCheckBox1.CheckRectColorDisabled = System.Drawing.Color.Gray;
            duiCheckBox1.CheckRectWidth = 17;
            duiCheckBox1.CheckState = System.Windows.Forms.CheckState.Unchecked;
            duiCheckBox1.ClientRectangle = new System.Drawing.Rectangle(0, 0, 75, 21);
            duiCheckBox1.ControlState = LayeredSkin.DirectUI.ControlStates.Normal;
            duiCheckBox1.CurrentCursor = System.Windows.Forms.Cursors.Default;
            duiCheckBox1.Cursor = System.Windows.Forms.Cursors.Default;
            duiCheckBox1.Dock = System.Windows.Forms.DockStyle.None;
            duiCheckBox1.Enabled = true;
            duiCheckBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            duiCheckBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            duiCheckBox1.Height = 21;
            duiCheckBox1.InnerPaddingWidth = 2;
            duiCheckBox1.InnerRectInflate = 3;
            duiCheckBox1.IsMoveParentPaint = true;
            duiCheckBox1.Left = 0;
            duiCheckBox1.Location = new System.Drawing.Point(0, 0);
            duiCheckBox1.Margin = new System.Windows.Forms.Padding(0);
            duiCheckBox1.Name = null;
            duiCheckBox1.ParentInvalidate = true;
            duiCheckBox1.ShowBorder = true;
            duiCheckBox1.Size = new System.Drawing.Size(75, 21);
            duiCheckBox1.SpaceBetweenCheckMarkAndText = 0;
            duiCheckBox1.Tag = null;
            duiCheckBox1.Text = "记住密码";
            duiCheckBox1.TextColorDisabled = System.Drawing.Color.Gray;
            duiCheckBox1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            duiCheckBox1.ThreeState = false;
            duiCheckBox1.Top = 0;
            duiCheckBox1.UncheckedHover = global::QQ_LayeredSkin.Properties.Resources.chkZdLogin_MouseBack;
            duiCheckBox1.UncheckedNormal = global::QQ_LayeredSkin.Properties.Resources.chkZdLogin_NormlBack;
            duiCheckBox1.UncheckedPressed = global::QQ_LayeredSkin.Properties.Resources.chkZdLogin_DownBack;
            duiCheckBox1.Visible = true;
            duiCheckBox1.Width = 75;
            this.layeredBaseControl1.DUIControls.AddRange(new LayeredSkin.DirectUI.DuiBaseControl[] {
            duiCheckBox1});
            this.layeredBaseControl1.Location = new System.Drawing.Point(8, 65);
            this.layeredBaseControl1.Name = "layeredBaseControl1";
            this.layeredBaseControl1.Size = new System.Drawing.Size(81, 21);
            this.layeredBaseControl1.TabIndex = 32;
            this.layeredBaseControl1.Text = "layeredBaseControl1";
            // 
            // layeredBaseControl2
            // 
            this.layeredBaseControl2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredBaseControl2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredBaseControl2.Borders.BottomWidth = 1;
            this.layeredBaseControl2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredBaseControl2.Borders.LeftWidth = 1;
            this.layeredBaseControl2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredBaseControl2.Borders.RightWidth = 1;
            this.layeredBaseControl2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredBaseControl2.Borders.TopWidth = 1;
            this.layeredBaseControl2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredBaseControl2.Canvas")));
            duiCheckBox2.AutoCheck = true;
            duiCheckBox2.AutoSize = true;
            duiCheckBox2.BackColor = System.Drawing.Color.Empty;
            duiCheckBox2.BackgroundImage = null;
            duiCheckBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            duiCheckBox2.BackgroundRender = null;
            duiCheckBox2.BitmapCache = false;
            duiCheckBox2.BorderPath = null;
            duiCheckBox2.BorderRender = null;
            duiCheckBox2.Borders.BottomColor = System.Drawing.Color.Empty;
            duiCheckBox2.Borders.BottomWidth = 1;
            duiCheckBox2.Borders.LeftColor = System.Drawing.Color.Empty;
            duiCheckBox2.Borders.LeftWidth = 1;
            duiCheckBox2.Borders.RightColor = System.Drawing.Color.Empty;
            duiCheckBox2.Borders.RightWidth = 1;
            duiCheckBox2.Borders.TopColor = System.Drawing.Color.Empty;
            duiCheckBox2.Borders.TopWidth = 1;
            duiCheckBox2.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft;
            duiCheckBox2.Checked = false;
            duiCheckBox2.CheckedHover = ((System.Drawing.Image)(resources.GetObject("duiCheckBox2.CheckedHover")));
            duiCheckBox2.CheckedNormal = ((System.Drawing.Image)(resources.GetObject("duiCheckBox2.CheckedNormal")));
            duiCheckBox2.CheckedPressed = ((System.Drawing.Image)(resources.GetObject("duiCheckBox2.CheckedPressed")));
            duiCheckBox2.CheckFlagColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(151)))), ((int)(((byte)(2)))));
            duiCheckBox2.CheckFlagColorDisabled = System.Drawing.Color.Gray;
            duiCheckBox2.CheckRectBackColorDisabled = System.Drawing.Color.Silver;
            duiCheckBox2.CheckRectBackColorHighLight = System.Drawing.Color.White;
            duiCheckBox2.CheckRectBackColorNormal = System.Drawing.Color.White;
            duiCheckBox2.CheckRectBackColorPressed = System.Drawing.Color.White;
            duiCheckBox2.CheckRectColor = System.Drawing.Color.DodgerBlue;
            duiCheckBox2.CheckRectColorDisabled = System.Drawing.Color.Gray;
            duiCheckBox2.CheckRectWidth = 17;
            duiCheckBox2.CheckState = System.Windows.Forms.CheckState.Unchecked;
            duiCheckBox2.ClientRectangle = new System.Drawing.Rectangle(0, 0, 75, 21);
            duiCheckBox2.ControlState = LayeredSkin.DirectUI.ControlStates.Normal;
            duiCheckBox2.CurrentCursor = System.Windows.Forms.Cursors.Default;
            duiCheckBox2.Cursor = System.Windows.Forms.Cursors.Default;
            duiCheckBox2.Dock = System.Windows.Forms.DockStyle.None;
            duiCheckBox2.Enabled = true;
            duiCheckBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            duiCheckBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            duiCheckBox2.Height = 21;
            duiCheckBox2.InnerPaddingWidth = 2;
            duiCheckBox2.InnerRectInflate = 3;
            duiCheckBox2.IsMoveParentPaint = true;
            duiCheckBox2.Left = 0;
            duiCheckBox2.Location = new System.Drawing.Point(0, 0);
            duiCheckBox2.Margin = new System.Windows.Forms.Padding(0);
            duiCheckBox2.Name = null;
            duiCheckBox2.ParentInvalidate = true;
            duiCheckBox2.ShowBorder = true;
            duiCheckBox2.Size = new System.Drawing.Size(75, 21);
            duiCheckBox2.SpaceBetweenCheckMarkAndText = 0;
            duiCheckBox2.Tag = null;
            duiCheckBox2.Text = "自动登录";
            duiCheckBox2.TextColorDisabled = System.Drawing.Color.Gray;
            duiCheckBox2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            duiCheckBox2.ThreeState = false;
            duiCheckBox2.Top = 0;
            duiCheckBox2.UncheckedHover = global::QQ_LayeredSkin.Properties.Resources.chkZdLogin_MouseBack;
            duiCheckBox2.UncheckedNormal = global::QQ_LayeredSkin.Properties.Resources.chkZdLogin_NormlBack;
            duiCheckBox2.UncheckedPressed = global::QQ_LayeredSkin.Properties.Resources.chkZdLogin_DownBack;
            duiCheckBox2.Visible = true;
            duiCheckBox2.Width = 75;
            this.layeredBaseControl2.DUIControls.AddRange(new LayeredSkin.DirectUI.DuiBaseControl[] {
            duiCheckBox2});
            this.layeredBaseControl2.Location = new System.Drawing.Point(129, 65);
            this.layeredBaseControl2.Name = "layeredBaseControl2";
            this.layeredBaseControl2.Size = new System.Drawing.Size(73, 21);
            this.layeredBaseControl2.TabIndex = 33;
            this.layeredBaseControl2.Text = "layeredBaseControl1";
            // 
            // layeredButton2
            // 
            this.layeredButton2.AdaptImage = true;
            this.layeredButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.BottomWidth = 1;
            this.layeredButton2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.LeftWidth = 1;
            this.layeredButton2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.RightWidth = 1;
            this.layeredButton2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.TopWidth = 1;
            this.layeredButton2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton2.Canvas")));
            this.layeredButton2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton2.HaloColor = System.Drawing.Color.White;
            this.layeredButton2.HaloSize = 5;
            this.layeredButton2.HoverImage = global::QQ_LayeredSkin.Properties.Resources.btnId_MouseBack;
            this.layeredButton2.IsPureColor = false;
            this.layeredButton2.Location = new System.Drawing.Point(179, 3);
            this.layeredButton2.Name = "layeredButton2";
            this.layeredButton2.NormalImage = global::QQ_LayeredSkin.Properties.Resources.btnId_NormlBack;
            this.layeredButton2.PressedImage = global::QQ_LayeredSkin.Properties.Resources.btnId_DownBack;
            this.layeredButton2.Radius = 10;
            this.layeredButton2.ShowBorder = true;
            this.layeredButton2.Size = new System.Drawing.Size(22, 24);
            this.layeredButton2.TabIndex = 31;
            this.layeredButton2.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton2.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.UserListShowDown);
            // 
            // FrmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(242)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(441, 342);
            this.Controls.Add(this.layeredButton7);
            this.Controls.Add(this.layeredButton6);
            this.Controls.Add(this.HeadImg);
            this.Controls.Add(this.BtnLogin);
            this.Controls.Add(this.lblogininfo);
            this.Controls.Add(this.layeredPanel1);
            this.Controls.Add(this.layeredPanel3);
            this.Name = "FrmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.layeredPanel1.ResumeLayout(false);
            this.layeredPanel3.ResumeLayout(false);
            this.layeredPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem 离线ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 忙碌ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 离开ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem q我吧ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 隐身ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 在线ToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 请勿打扰ToolStripMenuItem;
        private LayeredSkin.Controls.LayeredButton layeredButton7;
        private LayeredSkin.Controls.LayeredButton layeredButton6;
        private LayeredSkin.Controls.LayeredButton layeredButton1;
        private LayeredSkin.Controls.LayeredTextBox TxtPwd;
        private LayeredSkin.Controls.LayeredTextBox TxtUsername;
        private LayeredSkin.Controls.LayeredButton layeredButton4;
        private LayeredSkin.Controls.LayeredButton layeredButton3;
        private LayeredSkin.Controls.LayeredBaseControl HeadImg;
        private LayeredSkin.Controls.LayeredButton BtnLogin;
        private LayeredSkin.Controls.LayeredButton BtnSet;
        private LayeredSkin.Controls.LayeredButton BtnMini;
        private LayeredSkin.Controls.LayeredButton BtnClose;
        private LayeredSkin.Controls.LayeredLabel lblogininfo;
        private LayeredSkin.Controls.LayeredPanel layeredPanel1;
        private LayeredSkin.Controls.LayeredPanel layeredPanel3;
        private LayeredSkin.Controls.LayeredButton layeredButton2;
        private LayeredSkin.Controls.LayeredBaseControl layeredBaseControl1;
        private LayeredSkin.Controls.LayeredBaseControl layeredBaseControl2;
    }
}

