	/*--------------高德地图API汇总--------------*/
	/*----------------作者：BinGoo---------------*/
	/*-----------------2017-02-16----------------*/

	//初始化地图，找到网页div标签为'container'的容器显示地图
	//默认显示到当前所在的城市
	//如若显示指定位置并设为中心点则再resizeEnable: true后面加上如下代码
	//zoom:8,//地图放大等级
	//center: [112.397428, 23.90923] //地图中心位置  

	var map = new AMap.Map('container', //显示的容器
	{
		resizeEnable: true
	});
	
	//实时路况图层
	var trafficLayer = new AMap.TileLayer.Traffic({
			zIndex: 10
		});
	//设置地图样式
	//e样式表：
	//normal:默认样式
	//blue_night:夜蓝
	//light:浅色
	//fresh:鲜亮
	//dark:黑色
	function SetMapStyle(e) {
		map.setMapStyle(e);
	}
	//设置地图显示的内容(参数为bool值)
	//bg:背景
	//road:道路
	//building:建筑物
	//point:标注
	function SetFeatures(bg,road,building,point) {
		var features = [];
		if(bg){features.push('bg');}
		if(road){features.push('road');}
		if(building){features.push('building');}
		if(point){features.push('point');}
		map.setFeatures(features);
	}
	//设置地图显示的语言
	//en:显示英文底图
	//zh_en:显示中英文对照底图
	//zh_cn:显示中文底图
	function SetMapLanguage(lang) {
        map.setLang(lang);
    }
	//设置是否显示实时路况
	//true:显示
	//false:不显示
	function SetTrafficLayer(isShow){

		trafficLayer.setMap(map);
		//初始化默认关闭路况
		trafficLayer.hide();
		if (isShow) {
			trafficLayer.show();
		} else {
			trafficLayer.hide();
		}
	}
	//添加自定义标注点Marker
	//lon:经度;
	//lat:维度;
	//icoW:图标宽度;
	//icoH:图标高度;
	//icopx:图标X轴偏移量;
	//icopy:图片Y轴偏移量;
	//icopath:图标文件路径;
	//isdraggable:是否可拖拽
	function AddCustomerMark(lon,lat,icoW,icoH,icopx,icopy,icopath,isdraggable){
		lnglatXY = [lon, lat]; //已知点坐标
		var marker=new AMap.Marker({
			map: map,
			position: lnglatXY,//标记的位置点
			draggable: isdraggable,  //是否可拖动
			icon: new AMap.Icon({            
				size: new AMap.Size(icoW, icoH),  //图标大小
				image:icopath ,//图标地址
				imageOffset: new AMap.Pixel(icopx,icopy),//图标偏移量
			})        
		});
			OpenCustomerMarkInfo(marker);
	}

	//在指定标注点位置点击打开信息窗体
	function OpenCustomerMarkInfo(marker) {
		//构建信息窗体中显示的内容
		var info = [];
		info.push("<div><div><img style=\"float:left;\" src=\" http://webapi.amap.com/images/autonavi.png \"/></div> ");
		info.push("<div style=\"padding:0px 0px 0px 4px;\"><b></b>");
		info.push("电话 :    邮编 : ");
		info.push("地址 :</div></div>");
		infoWindow = new AMap.InfoWindow({
			content: info.join("<br/>")  //使用默认信息窗体框样式，显示信息内容
		});
		//鼠标点击marker弹出自定义的信息窗体
		AMap.event.addListener(marker, 'click', function() {
			infoWindow.open(map, marker.getPosition());
		});
	}
	/*---------------------------公交查询模块开始---------------------------*/
	/*
	* 该示例主要流程分为三个步骤
	* 1. 首先调用公交路线查询服务(lineSearch)
	* 2. 根据返回结果解析，输出解析结果(lineSearch_Callback)
	* 3. 在地图上绘制公交线路()
	*/
    /*公交线路查询*/
	//根据城市和公交线路名称查找公交线路
    function GetBuslineForLineName(cityName,lineName) {
        //实例化公交线路查询类，只取回一条路线
        var linesearch = new AMap.LineSearch({
            pageIndex: 1,
            city: cityName,
            pageSize: 1,
            extensions: 'all'
        });
        //搜索“536”相关公交线路
        linesearch.search(lineName, function(status, result) {
            if (status === 'complete' && result.info === 'OK') {
                GetBuslineForLineName_Callback(result);
                
            } else {
                alert(result);
            }
        });
    }
    /*公交路线查询服务返回数据解析概况*/
    function GetBuslineForLineName_Callback(data) {
        var lineArr = data.lineInfo;
        var lineNum = data.lineInfo.length;
        if (lineNum == 0) {
        } else {
            for (var i = 0; i < lineNum; i++) {
                var pathArr = lineArr[i].path;
                var stops = lineArr[i].via_stops;
                var startPot = stops[0].location;
                var endPot = stops[stops.length - 1].location;

                if (i == 0) 
					drawbusLine(startPot, endPot, pathArr);
            }
        }
    }
    /*绘制路线*/
    function drawbusLine(startPot, endPot, BusArr) {
				
        //绘制起点，终点
        new AMap.Marker({
            map: map,
            position: [startPot.lng, startPot.lat], //基点位置
            icon: "http://webapi.amap.com/theme/v1.3/markers/n/start.png",
            zIndex: 10
        });
        new AMap.Marker({
            map: map,
            position: [endPot.lng, endPot.lat], //基点位置
            icon: "http://webapi.amap.com/theme/v1.3/markers/n/end.png",
            zIndex: 10
        });
        //绘制乘车的路线
        busPolyline = new AMap.Polyline({
            map: map,
            path: BusArr,
            strokeColor: "#09f",//线颜色
            strokeOpacity: 0.8,//线透明度
            strokeWeight: 6//线宽
        });
        map.setFitView();
    }
	//根据城市名称和起点终点查找公交线路
	function GetBusLineForStation(cityName,startAddress,endAddress){
		var transOptions = {
        map: map,
        city:cityName,
        panel: '',                           
        policy: AMap.TransferPolicy.LEAST_TIME //乘车策略
		};
		//构造公交换乘类
		var transfer = new AMap.Transfer(transOptions);
		//根据起、终点名称查询公交换乘路线
		transfer.search([
		{keyword: startAddress,city:cityName},
		//第一个元素city缺省时取transOptions的city属性
		{keyword: endAddress,city:cityName}
		//第二个元素city缺省时取transOptions的cityd属性,
		//没有cityd属性时取city属性
		]);
	}
	
	/*---------------------------公交查询模块结束---------------------------*/

	/*---------------------------驾车查询模块开始---------------------------*/
	//根据起点终点查询驾车线路
	function GetDravingLineForAddress(startCity,startAddress,endCity,endAddress){
		//构造路线导航类
		var driving = new AMap.Driving({
			map: map,
			panel: ""
		}); 
		// 根据起终点名称规划驾车导航路线
		driving.search([
			{keyword: startAddress,city:startCity},
			{keyword: endCity,city:endCity}
		]);
	}
	//根据起点终点经纬度查询驾车线路（可拖拽选择多个途经点）
	function GetEnableDragDravingLineForLonLat(startLon,startlat,endlon,endlat){
		var path = [];
		path.push([startLon,startlat]);
		path.push([endlon, endlat]);
		map.plugin("AMap.DragRoute", function() {
			route = new AMap.DragRoute(map, path, AMap.DrivingPolicy.LEAST_FEE); //构造拖拽导航类
			route.search(); //查询导航路径并开启拖拽导航
		});
	}
	/*---------------------------驾车查询模块结束---------------------------*/

	/*---------------------------步行查询模块开始---------------------------*/
	//根据起点终点查询步行线路
	function GetWorkingLineForAddress(startCity,startAddress,endCity,endAddress){
		//构造路线导航类
		var walking = new AMap.Walking({
			map: map,
			panel: ""
		}); 
		// 根据起终点名称规划驾车导航路线
		walking.search([
			{keyword: startAddress,city:startCity},
			{keyword: endCity,city:endCity}
		]);
	}
	//根据起点终点经纬度查询步行线路
	function GetWorkingLineForLonLat(startLon,startlat,endlon,endlat){
		 //步行导航
		var walking = new AMap.Walking({
			map: map,
			panel: ""
		}); 
		//根据起终点坐标规划步行路线
		walking.search([startLon, startlat], [endlon,endlat]);
	}
	/*---------------------------步行查询模块结束---------------------------*/

	/*---------------------------骑行查询模块开始---------------------------*/
	//根据起点终点查询步行线路
	function GetRidingLineForAddress(startCity,startAddress,endCity,endAddress){
		 //步行导航
		var riding = new AMap.Riding({
			map: map,
			panel: ""
		}); 
		// 根据起终点名称规划驾车导航路线
		riding.search([
			{keyword: startAddress,city:startCity},
			{keyword: endCity,city:endCity}
		]);
	}
	//根据起点终点经纬度查询步行线路
	function GetRidingLineForLonLat(startLon,startlat,endlon,endlat){
		 //步行导航
		var riding = new AMap.Riding({
			map: map,
			panel: ""
		}); 
		//根据起终点坐标规划步行路线
		riding.search([startLon, startlat], [endlon,endlat]);
	}
	/*---------------------------骑行查询模块结束---------------------------*/

	/*---------------------------地理位置编码开始---------------------------*/
	//正向编码，根据详细地址查询经纬度等信息
	function GetLonLatForAddress(address) {
        var geocoder = new AMap.Geocoder({
            city: "全国", //城市，默认：“全国”
            radius: 1000 //范围，默认：500
        });
        //地理编码,返回地理编码结果
        geocoder.getLocation(address, function(status, result) {
            if (status === 'complete' && result.info === 'OK') {
                GetLonLatForAddress_CallBack(result);
            }
        });
    }
    //正向地理编码返回结果展示
    function GetLonLatForAddress_CallBack(data) {
        var resultStr = "";
        //地理编码结果数组
        var geocode = data.geocodes;
        for (var i = 0; i < geocode.length; i++) {
            //拼接输出html
            resultStr += '地址' + geocode[i].formattedAddress+ '的地理编码结果是:(' + geocode[i].location.getLng() + ',' + geocode[i].location.getLat() + ")" + "\r\n匹配级别：" + geocode[i].level + "";
            
        }
		alert(resultStr);
    }
	//逆向编码，根据经纬度查询详细地址等信息
	function GetAddressForLonLat(lon,lat) {  //逆地理编码
        var geocoder = new AMap.Geocoder({
            radius: 1000,
            extensions: "all"
        });        
		var lnglatXY=[lon,lat];
        geocoder.getAddress(lnglatXY, function(status, result) {
            if (status === 'complete' && result.info === 'OK') {
                GetAddressForLonLat_CallBack(result);
            }
        });    
    }
	//逆向地理编码返回结果展示
    function GetAddressForLonLat_CallBack(data) {
        var address = data.regeocode.formattedAddress; //返回地址描述
		alert(address);
    }
	/*---------------------------地理位置编码结束---------------------------*/

	/*-------------------------------测试区域开始-------------------------------------*/
	//GetBusLineForStation('广州','大沙地','黄村');
	//GetBusLineForStation('广州','燕塘','白云机场');
    //GetBuslineForLineName('广州','564');
	//SetTrafficLayer(true);
	//GetDravingLineForAddress('广州','大沙地','广州','黄村');
	//GetEnableDragDravingLineForLonLat(112.397428,23.90923,109.123456,28.123456);
	//GetWorkingLineForAddress('广州','大沙地','广州','黄村');
	//GetWorkingLineForLonLat(116.399028, 39.845042, 116.436281, 39.880719);
	GetRidingLineForAddress('广州','大沙地','广州','黄村');
	GetRidingLineForLonLat(116.399028, 39.845042, 116.436281, 39.880719);
	//GetLonLatForAddress('广东省广州市天河区大观中路95号科汇园');
	//GetAddressForLonLat(112.397428, 23.90923);
	/*-------------------------------测试区域结束-------------------------------------*/