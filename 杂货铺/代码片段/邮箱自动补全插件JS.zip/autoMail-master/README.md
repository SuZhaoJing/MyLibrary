# Auto-Email-Plugin
A jQuery plugin that autocomplete email address in input fields. 

## Demo
[http://www.zhangshuzheng.cn/autoMail/demo/](http://www.zhangshuzheng.cn/autoMail/demo/)

## How to use
```js
$('#email1,#email2,#email3,#email4,#email5,#email6').autoMail({
	emails:['qq.com','163.com','126.com','sina.com','sohu.com','yahoo.cn','gmail.com','hotmail.com','live.cn']
});  
```
## 效果图

![效果图](demo/autoMail-demo.png)

## License
MIT
